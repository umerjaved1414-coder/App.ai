package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.ui.DukaanViewModel
import com.example.ui.NavTab
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ExpensesScreen
import com.example.ui.screens.KhataScreen
import com.example.ui.screens.PosBillingScreen
import com.example.ui.screens.ProductsScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SuppliersScreen
import com.example.ui.theme.DukaanGold
import com.example.ui.theme.DukaanGreenPrimary
import com.example.ui.theme.SmartDukaanTheme

class MainActivity : ComponentActivity() {

    private val viewModel: DukaanViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SmartDukaanTheme {
                val currentTab by viewModel.currentTab.collectAsState()
                val settings by viewModel.settings.collectAsState()
                val cartItems by viewModel.cartItems.collectAsState()
                val currentLang by viewModel.language.collectAsState()
                val selectedCustomerDetail by viewModel.selectedCustomerForDetail.collectAsState()

                var showMoreMenu by remember { mutableStateOf(false) }

                // System BackHandler
                BackHandler(enabled = currentTab != NavTab.HOME || selectedCustomerDetail != null) {
                    if (selectedCustomerDetail != null) {
                        viewModel.selectCustomerForDetail(null)
                    } else if (currentTab != NavTab.HOME) {
                        viewModel.navigateTo(NavTab.HOME)
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        TopAppBar(
                            title = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.Store,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = settings?.shopName ?: "Smart Dukaan Pro",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 17.sp,
                                            color = Color.White
                                        )
                                        Text(
                                            text = when (currentTab) {
                                                NavTab.HOME -> "Markaz (Dashboard)"
                                                NavTab.BILLING -> "Naya Bill (Point of Sale)"
                                                NavTab.PRODUCTS -> "Mal o Saman (Inventory)"
                                                NavTab.KHATA -> "Grahak Khata (Udhar Ledger)"
                                                NavTab.REPORTS -> "Munafa Report (Financials)"
                                                NavTab.EXPENSES -> "Dukaan Akhrajat (Expenses)"
                                                NavTab.SUPPLIERS -> "Suppliers & Purchases"
                                                NavTab.SETTINGS -> "Settings (ترتیبات)"
                                            },
                                            fontSize = 11.sp,
                                            color = Color.White.copy(alpha = 0.85f)
                                        )
                                    }
                                }
                            },
                            actions = {
                                // Language pill button
                                Box(
                                    modifier = Modifier
                                        .padding(end = 8.dp)
                                        .background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                                        .clickable {
                                            val nextLang = when (currentLang) {
                                                AppLanguage.ROMAN_URDU -> AppLanguage.URDU
                                                AppLanguage.URDU -> AppLanguage.ENGLISH
                                                AppLanguage.ENGLISH -> AppLanguage.ROMAN_URDU
                                            }
                                            viewModel.setLanguage(nextLang)
                                        }
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = when (currentLang) {
                                            AppLanguage.ROMAN_URDU -> "Urdu"
                                            AppLanguage.URDU -> "EN"
                                            AppLanguage.ENGLISH -> "آسان"
                                        },
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = DukaanGreenPrimary,
                                titleContentColor = Color.White
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 6.dp
                        ) {
                            NavigationBarItem(
                                selected = currentTab == NavTab.HOME,
                                onClick = { viewModel.navigateTo(NavTab.HOME) },
                                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                                label = { Text("Home", fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = DukaanGreenPrimary,
                                    indicatorColor = Color(0xFFD1E7DD)
                                )
                            )

                            NavigationBarItem(
                                selected = currentTab == NavTab.BILLING,
                                onClick = { viewModel.navigateTo(NavTab.BILLING) },
                                icon = {
                                    if (cartItems.isNotEmpty()) {
                                        BadgedBox(badge = {
                                            Box(
                                                modifier = Modifier
                                                    .background(DukaanGold, RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 4.dp)
                                            ) {
                                                Text("${cartItems.size}", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                            }
                                        }) {
                                            Icon(Icons.Default.PointOfSale, contentDescription = "Billing")
                                        }
                                    } else {
                                        Icon(Icons.Default.PointOfSale, contentDescription = "Billing")
                                    }
                                },
                                label = { Text("Bill", fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = DukaanGreenPrimary,
                                    indicatorColor = Color(0xFFD1E7DD)
                                )
                            )

                            NavigationBarItem(
                                selected = currentTab == NavTab.PRODUCTS,
                                onClick = { viewModel.navigateTo(NavTab.PRODUCTS) },
                                icon = { Icon(Icons.Default.Inventory, contentDescription = "Products") },
                                label = { Text("Stock", fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = DukaanGreenPrimary,
                                    indicatorColor = Color(0xFFD1E7DD)
                                )
                            )

                            NavigationBarItem(
                                selected = currentTab == NavTab.KHATA,
                                onClick = {
                                    viewModel.selectCustomerForDetail(null)
                                    viewModel.navigateTo(NavTab.KHATA)
                                },
                                icon = { Icon(Icons.Default.ReceiptLong, contentDescription = "Khata") },
                                label = { Text("Khata", fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = DukaanGreenPrimary,
                                    indicatorColor = Color(0xFFD1E7DD)
                                )
                            )

                            NavigationBarItem(
                                selected = currentTab == NavTab.REPORTS,
                                onClick = { viewModel.navigateTo(NavTab.REPORTS) },
                                icon = { Icon(Icons.Default.Assessment, contentDescription = "Reports") },
                                label = { Text("Munafa", fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = DukaanGreenPrimary,
                                    indicatorColor = Color(0xFFD1E7DD)
                                )
                            )

                            // More Tab (Expenses, Suppliers, Settings)
                            NavigationBarItem(
                                selected = currentTab == NavTab.EXPENSES || currentTab == NavTab.SUPPLIERS || currentTab == NavTab.SETTINGS,
                                onClick = { showMoreMenu = true },
                                icon = {
                                    Box {
                                        Icon(Icons.Default.MoreHoriz, contentDescription = "More")
                                        DropdownMenu(
                                            expanded = showMoreMenu,
                                            onDismissRequest = { showMoreMenu = false }
                                        ) {
                                            DropdownMenuItem(
                                                text = { Text("Dukaan Kharcha (Expenses)") },
                                                leadingIcon = { Icon(Icons.Default.MoneyOff, contentDescription = null) },
                                                onClick = {
                                                    viewModel.navigateTo(NavTab.EXPENSES)
                                                    showMoreMenu = false
                                                }
                                            )
                                            DropdownMenuItem(
                                                text = { Text("Suppliers & Khareedari (Wholesale)") },
                                                leadingIcon = { Icon(Icons.Default.LocalShipping, contentDescription = null) },
                                                onClick = {
                                                    viewModel.navigateTo(NavTab.SUPPLIERS)
                                                    showMoreMenu = false
                                                }
                                            )
                                            DropdownMenuItem(
                                                text = { Text("Settings & Profile (ترتیبات)") },
                                                leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null) },
                                                onClick = {
                                                    viewModel.navigateTo(NavTab.SETTINGS)
                                                    showMoreMenu = false
                                                }
                                            )
                                        }
                                    }
                                },
                                label = { Text("More", fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = DukaanGreenPrimary,
                                    indicatorColor = Color(0xFFD1E7DD)
                                )
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentTab) {
                            NavTab.HOME -> DashboardScreen(
                                viewModel = viewModel,
                                onNavigate = { tab -> viewModel.navigateTo(tab) }
                            )
                            NavTab.BILLING -> PosBillingScreen(viewModel = viewModel)
                            NavTab.PRODUCTS -> ProductsScreen(viewModel = viewModel)
                            NavTab.KHATA -> KhataScreen(viewModel = viewModel)
                            NavTab.REPORTS -> ReportsScreen(viewModel = viewModel)
                            NavTab.EXPENSES -> ExpensesScreen(viewModel = viewModel)
                            NavTab.SUPPLIERS -> SuppliersScreen(viewModel = viewModel)
                            NavTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}
