package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.BillDao
import com.example.data.local.dao.BillItemDao
import com.example.data.local.dao.CustomerDao
import com.example.data.local.dao.CustomerLedgerDao
import com.example.data.local.dao.ExpenseDao
import com.example.data.local.dao.ProductDao
import com.example.data.local.dao.PurchaseDao
import com.example.data.local.dao.PurchaseItemDao
import com.example.data.local.dao.ShopSettingsDao
import com.example.data.local.dao.StockMovementDao
import com.example.data.local.dao.SupplierDao
import com.example.data.local.dao.SupplierLedgerDao
import com.example.data.local.entity.BillEntity
import com.example.data.local.entity.BillItemEntity
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.CustomerLedgerEntryEntity
import com.example.data.local.entity.ExpenseEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.PurchaseEntity
import com.example.data.local.entity.PurchaseItemEntity
import com.example.data.local.entity.ShopSettingsEntity
import com.example.data.local.entity.StockMovementEntity
import com.example.data.local.entity.SupplierEntity
import com.example.data.local.entity.SupplierLedgerEntryEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ProductEntity::class,
        CustomerEntity::class,
        CustomerLedgerEntryEntity::class,
        SupplierEntity::class,
        SupplierLedgerEntryEntity::class,
        BillEntity::class,
        BillItemEntity::class,
        PurchaseEntity::class,
        PurchaseItemEntity::class,
        ExpenseEntity::class,
        StockMovementEntity::class,
        ShopSettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun productDao(): ProductDao
    abstract fun customerDao(): CustomerDao
    abstract fun customerLedgerDao(): CustomerLedgerDao
    abstract fun supplierDao(): SupplierDao
    abstract fun supplierLedgerDao(): SupplierLedgerDao
    abstract fun billDao(): BillDao
    abstract fun billItemDao(): BillItemDao
    abstract fun purchaseDao(): PurchaseDao
    abstract fun purchaseItemDao(): PurchaseItemDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun stockMovementDao(): StockMovementDao
    abstract fun shopSettingsDao(): ShopSettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "smart_dukaan_pro.db"
                )
                    .addCallback(object : RoomDatabase.Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            CoroutineScope(Dispatchers.IO).launch {
                                INSTANCE?.let { database ->
                                    seedDefaultData(database)
                                }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        suspend fun seedDefaultData(db: AppDatabase) {
            // Seed Settings
            db.shopSettingsDao().saveSettings(
                ShopSettingsEntity(
                    id = 1,
                    shopName = "Bismillah Kiryana Store",
                    ownerName = "Muhammad Ali",
                    phone = "0300-1234567",
                    address = "Main Bazar, Lahore",
                    currencySymbol = "Rs.",
                    language = "ROMAN_URDU",
                    receiptFooter = "Shukriya! Dobara Tashreef Layen.",
                    defaultLowStockThreshold = 5.0,
                    allowNegativeStock = false
                )
            )

            // Seed Sample Pakistani Kiryana Products
            val sampleProducts = listOf(
                ProductEntity(
                    name = "Atta Chakki 10kg Bag",
                    urduName = "آٹا چکی 10 کلو",
                    barcode = "89640001001",
                    category = "Atta & Dalen",
                    unit = "Bag",
                    costPrice = 1380.0,
                    sellingPrice = 1450.0,
                    currentStock = 25.0,
                    minStockThreshold = 5.0
                ),
                ProductEntity(
                    name = "Chawal Basmati Super Kernel 1kg",
                    urduName = "چاول باسمتی 1 کلو",
                    barcode = "89640001002",
                    category = "Atta & Dalen",
                    unit = "Kg",
                    costPrice = 310.0,
                    sellingPrice = 350.0,
                    currentStock = 40.0,
                    minStockThreshold = 10.0
                ),
                ProductEntity(
                    name = "Dal Chana Special 1kg",
                    urduName = "دال چنا 1 کلو",
                    barcode = "89640001003",
                    category = "Atta & Dalen",
                    unit = "Kg",
                    costPrice = 240.0,
                    sellingPrice = 270.0,
                    currentStock = 30.0,
                    minStockThreshold = 8.0
                ),
                ProductEntity(
                    name = "Dal Moong Dhuli 1kg",
                    urduName = "دال مونگ 1 کلو",
                    barcode = "89640001004",
                    category = "Atta & Dalen",
                    unit = "Kg",
                    costPrice = 290.0,
                    sellingPrice = 330.0,
                    currentStock = 20.0,
                    minStockThreshold = 5.0
                ),
                ProductEntity(
                    name = "Cheeni / White Sugar 1kg",
                    urduName = "چینی سفید 1 کلو",
                    barcode = "89640001005",
                    category = "Chai & Cheeni",
                    unit = "Kg",
                    costPrice = 142.0,
                    sellingPrice = 152.0,
                    currentStock = 85.0,
                    minStockThreshold = 15.0
                ),
                ProductEntity(
                    name = "Tapal Danedar Chai 450g",
                    urduName = "تپال دانے دار چائے 450 گرام",
                    barcode = "89640001006",
                    category = "Chai & Cheeni",
                    unit = "Packet",
                    costPrice = 610.0,
                    sellingPrice = 670.0,
                    currentStock = 18.0,
                    minStockThreshold = 5.0
                ),
                ProductEntity(
                    name = "Sufi Banaspati Ghee 1kg Pouch",
                    urduName = "صوفی بناسپتی گھی 1 کلو",
                    barcode = "89640001007",
                    category = "Ghee & Tel",
                    unit = "Pouch",
                    costPrice = 490.0,
                    sellingPrice = 530.0,
                    currentStock = 35.0,
                    minStockThreshold = 8.0
                ),
                ProductEntity(
                    name = "Habib Cooking Oil 1L",
                    urduName = "حبیب کوکنگ آئل 1 لیٹر",
                    barcode = "89640001008",
                    category = "Ghee & Tel",
                    unit = "Liter",
                    costPrice = 520.0,
                    sellingPrice = 570.0,
                    currentStock = 22.0,
                    minStockThreshold = 6.0
                ),
                ProductEntity(
                    name = "Shan Bombay Biryani Masala",
                    urduName = "شان بمبئی بریانی مصالحہ",
                    barcode = "89640001009",
                    category = "Masalay",
                    unit = "Packet",
                    costPrice = 115.0,
                    sellingPrice = 135.0,
                    currentStock = 45.0,
                    minStockThreshold = 10.0
                ),
                ProductEntity(
                    name = "National Red Chilli Powder 200g",
                    urduName = "نیشنل لال مرچ 200 گرام",
                    barcode = "89640001010",
                    category = "Masalay",
                    unit = "Packet",
                    costPrice = 210.0,
                    sellingPrice = 245.0,
                    currentStock = 14.0,
                    minStockThreshold = 5.0
                ),
                ProductEntity(
                    name = "Olper's Full Cream Milk 1L",
                    urduName = "اولپرز دودھ 1 لیٹر",
                    barcode = "89640001011",
                    category = "Beverages & Milk",
                    unit = "Pack",
                    costPrice = 265.0,
                    sellingPrice = 290.0,
                    currentStock = 3.0, // low stock test
                    minStockThreshold = 10.0
                ),
                ProductEntity(
                    name = "Safeguard Soap Pure White 110g",
                    urduName = "سیف گارڈ صابن",
                    barcode = "89640001012",
                    category = "Soap & Detergent",
                    unit = "Piece",
                    costPrice = 120.0,
                    sellingPrice = 140.0,
                    currentStock = 2.0, // low stock test
                    minStockThreshold = 8.0
                ),
                ProductEntity(
                    name = "Surf Excel Detergent Powder 500g",
                    urduName = "سرف ایکسل 500 گرام",
                    barcode = "89640001013",
                    category = "Soap & Detergent",
                    unit = "Packet",
                    costPrice = 330.0,
                    sellingPrice = 375.0,
                    currentStock = 12.0,
                    minStockThreshold = 5.0
                ),
                ProductEntity(
                    name = "Peek Freans Super Biscuit Half Roll",
                    urduName = "سوپر بسکٹ ہاف رول",
                    barcode = "89640001014",
                    category = "Snacks & Biscuits",
                    unit = "Packet",
                    costPrice = 42.0,
                    sellingPrice = 50.0,
                    currentStock = 60.0,
                    minStockThreshold = 12.0
                )
            )
            db.productDao().insertAll(sampleProducts)

            // Seed Sample Customers
            val c1Id = db.customerDao().insertCustomer(
                CustomerEntity(
                    name = "Haji Tariq Mehmood",
                    phone = "0301-7654321",
                    address = "Street 4, Near Jamia Masjid",
                    openingBalance = 0.0
                )
            )
            val c2Id = db.customerDao().insertCustomer(
                CustomerEntity(
                    name = "Master Aslam School Walay",
                    phone = "0321-9876543",
                    address = "House 12, Block B",
                    openingBalance = 0.0
                )
            )
            val c3Id = db.customerDao().insertCustomer(
                CustomerEntity(
                    name = "Chaudhary Nadeem",
                    phone = "0333-5551234",
                    address = "Dera Chaudhary, Chak 22",
                    openingBalance = 0.0
                )
            )

            // Add Initial Ledger records for customers
            db.customerLedgerDao().insertEntry(
                CustomerLedgerEntryEntity(
                    customerId = c1Id,
                    type = "DEBIT",
                    amount = 1850.0,
                    description = "Sabqa Khata Udhar (Previous Balance)",
                    timestamp = System.currentTimeMillis() - 86400000L * 3
                )
            )
            db.customerLedgerDao().insertEntry(
                CustomerLedgerEntryEntity(
                    customerId = c1Id,
                    type = "CREDIT",
                    amount = 500.0,
                    description = "Naqad Jama Karwaya (Cash Payment)",
                    timestamp = System.currentTimeMillis() - 86400000L * 1
                )
            )
            db.customerLedgerDao().insertEntry(
                CustomerLedgerEntryEntity(
                    customerId = c2Id,
                    type = "DEBIT",
                    amount = 920.0,
                    description = "Rashan Khata (Grocery Credit)",
                    timestamp = System.currentTimeMillis() - 86400000L * 2
                )
            )

            // Seed Sample Suppliers
            val s1Id = db.supplierDao().insertSupplier(
                SupplierEntity(
                    name = "Akbari Mandi Wholesale Merchants",
                    phone = "0300-8889999",
                    address = "Shop 44, Akbari Mandi, Lahore"
                )
            )
            val s2Id = db.supplierDao().insertSupplier(
                SupplierEntity(
                    name = "Nestle & Grocery Distributors",
                    phone = "0345-1122334",
                    address = "Main G.T Road Agency"
                )
            )

            db.supplierLedgerDao().insertEntry(
                SupplierLedgerEntryEntity(
                    supplierId = s1Id,
                    type = "PAYABLE",
                    amount = 25000.0,
                    description = "Atta & Dalen Stock Delivery"
                )
            )
            db.supplierLedgerDao().insertEntry(
                SupplierLedgerEntryEntity(
                    supplierId = s1Id,
                    type = "PAID",
                    amount = 15000.0,
                    description = "Payment via Bank Transfer"
                )
            )

            // Seed Sample Expense
            db.expenseDao().insertExpense(
                ExpenseEntity(
                    category = "Electricity Bill",
                    amount = 4500.0,
                    paymentMethod = "Cash",
                    notes = "Dukaan Bijli Meter Bill",
                    timestamp = System.currentTimeMillis() - 86400000L
                )
            )
            db.expenseDao().insertExpense(
                ExpenseEntity(
                    category = "Packaging / Lifafay",
                    amount = 650.0,
                    paymentMethod = "Cash",
                    notes = "Shopper lifafay 2kg",
                    timestamp = System.currentTimeMillis()
                )
            )
        }
    }
}
