package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.local.entity.BillEntity
import com.example.data.local.entity.BillItemEntity
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.CustomerLedgerEntryEntity
import com.example.data.local.entity.ExpenseEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.PurchaseEntity
import com.example.data.local.entity.PurchaseItemEntity
import com.example.data.local.entity.ShopSettingsEntity
import com.example.data.local.entity.StockMovementEntity
import com.example.data.local.entity.SupplierEntity
import com.example.data.local.entity.SupplierLedgerEntryEntity
import com.example.data.model.FinancialReport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

class DukaanRepository(private val db: AppDatabase) {

    // Products
    val allProducts: Flow<List<ProductEntity>> = db.productDao().getAllActiveProducts()
    val lowStockProducts: Flow<List<ProductEntity>> = db.productDao().getLowStockProducts()
    val totalProductCount: Flow<Int> = db.productDao().getProductCount()
    val lowStockCount: Flow<Int> = db.productDao().getLowStockCount()

    fun searchProducts(query: String): Flow<List<ProductEntity>> {
        return db.productDao().searchProducts(query)
    }

    suspend fun getProductById(id: Long): ProductEntity? = withContext(Dispatchers.IO) {
        db.productDao().getProductById(id)
    }

    suspend fun getProductByBarcode(barcode: String): ProductEntity? = withContext(Dispatchers.IO) {
        db.productDao().getProductByBarcode(barcode)
    }

    suspend fun saveProduct(product: ProductEntity): Long = withContext(Dispatchers.IO) {
        if (product.id == 0L) {
            val newId = db.productDao().insertProduct(product)
            db.stockMovementDao().insertMovement(
                StockMovementEntity(
                    productId = newId,
                    productName = product.name,
                    changeQuantity = product.currentStock,
                    type = "INITIAL",
                    reason = "New Product added"
                )
            )
            newId
        } else {
            db.productDao().updateProduct(product)
            product.id
        }
    }

    suspend fun adjustStock(
        productId: Long,
        delta: Double,
        reason: String,
        type: String = "CORRECTION"
    ) = withContext(Dispatchers.IO) {
        db.withTransaction {
            val product = db.productDao().getProductById(productId) ?: return@withTransaction
            db.productDao().adjustStock(productId, delta)
            db.stockMovementDao().insertMovement(
                StockMovementEntity(
                    productId = productId,
                    productName = product.name,
                    changeQuantity = delta,
                    type = type,
                    reason = reason
                )
            )
        }
    }

    suspend fun archiveProduct(productId: Long) = withContext(Dispatchers.IO) {
        db.productDao().archiveProduct(productId)
    }

    // Customers
    val allCustomers: Flow<List<CustomerEntity>> = db.customerDao().getAllCustomers()

    fun searchCustomers(query: String): Flow<List<CustomerEntity>> {
        return db.customerDao().searchCustomers(query)
    }

    suspend fun getCustomerById(id: Long): CustomerEntity? = withContext(Dispatchers.IO) {
        db.customerDao().getCustomerById(id)
    }

    suspend fun saveCustomer(customer: CustomerEntity): Long = withContext(Dispatchers.IO) {
        if (customer.id == 0L) {
            val newId = db.customerDao().insertCustomer(customer)
            if (customer.openingBalance > 0) {
                db.customerLedgerDao().insertEntry(
                    CustomerLedgerEntryEntity(
                        customerId = newId,
                        type = "DEBIT",
                        amount = customer.openingBalance,
                        description = "Opening Udhar Balance"
                    )
                )
            }
            newId
        } else {
            db.customerDao().updateCustomer(customer)
            customer.id
        }
    }

    fun getCustomerLedger(customerId: Long): Flow<List<CustomerLedgerEntryEntity>> {
        return db.customerLedgerDao().getLedgerForCustomer(customerId)
    }

    fun getCustomerBalance(customerId: Long): Flow<Double> {
        return db.customerLedgerDao().getCustomerBalance(customerId)
    }

    suspend fun recordCustomerPayment(
        customerId: Long,
        amount: Double,
        description: String
    ): Long = withContext(Dispatchers.IO) {
        db.customerLedgerDao().insertEntry(
            CustomerLedgerEntryEntity(
                customerId = customerId,
                type = "CREDIT",
                amount = amount,
                description = description.ifBlank { "Naqad Jama (Cash Received)" }
            )
        )
    }

    suspend fun recordCustomerAdjustment(
        customerId: Long,
        amount: Double,
        isDebit: Boolean,
        description: String
    ): Long = withContext(Dispatchers.IO) {
        db.customerLedgerDao().insertEntry(
            CustomerLedgerEntryEntity(
                customerId = customerId,
                type = if (isDebit) "DEBIT" else "CREDIT",
                amount = amount,
                description = description
            )
        )
    }

    // Suppliers
    val allSuppliers: Flow<List<SupplierEntity>> = db.supplierDao().getAllSuppliers()

    suspend fun saveSupplier(supplier: SupplierEntity): Long = withContext(Dispatchers.IO) {
        if (supplier.id == 0L) {
            val newId = db.supplierDao().insertSupplier(supplier)
            if (supplier.openingBalance > 0) {
                db.supplierLedgerDao().insertEntry(
                    SupplierLedgerEntryEntity(
                        supplierId = newId,
                        type = "PAYABLE",
                        amount = supplier.openingBalance,
                        description = "Opening Payable Balance"
                    )
                )
            }
            newId
        } else {
            db.supplierDao().updateSupplier(supplier)
            supplier.id
        }
    }

    fun getSupplierLedger(supplierId: Long): Flow<List<SupplierLedgerEntryEntity>> {
        return db.supplierLedgerDao().getLedgerForSupplier(supplierId)
    }

    fun getSupplierBalance(supplierId: Long): Flow<Double> {
        return db.supplierLedgerDao().getSupplierBalance(supplierId)
    }

    suspend fun recordSupplierPayment(
        supplierId: Long,
        amount: Double,
        description: String
    ): Long = withContext(Dispatchers.IO) {
        db.supplierLedgerDao().insertEntry(
            SupplierLedgerEntryEntity(
                supplierId = supplierId,
                type = "PAID",
                amount = amount,
                description = description.ifBlank { "Payment Paid to Supplier" }
            )
        )
    }

    suspend fun recordPurchase(
        purchase: PurchaseEntity,
        items: List<PurchaseItemEntity>
    ): Long = withContext(Dispatchers.IO) {
        db.withTransaction {
            val purchaseId = db.purchaseDao().insertPurchase(purchase)
            val itemsWithId = items.map { it.copy(purchaseId = purchaseId) }
            db.purchaseItemDao().insertAll(itemsWithId)

            for (item in items) {
                db.productDao().adjustStock(item.productId, item.quantity)
                db.stockMovementDao().insertMovement(
                    StockMovementEntity(
                        productId = item.productId,
                        productName = item.productName,
                        changeQuantity = item.quantity,
                        type = "PURCHASE",
                        reason = "Invoice: ${purchase.invoiceNumber}"
                    )
                )
            }

            if (purchase.supplierId != null && purchase.balanceDue > 0) {
                db.supplierLedgerDao().insertEntry(
                    SupplierLedgerEntryEntity(
                        supplierId = purchase.supplierId,
                        purchaseId = purchaseId,
                        type = "PAYABLE",
                        amount = purchase.balanceDue,
                        description = "Purchase Inv #${purchase.invoiceNumber}"
                    )
                )
            }
            purchaseId
        }
    }

    // Bills & POS
    val allBills: Flow<List<BillEntity>> = db.billDao().getAllBills()
    val recentBills: Flow<List<BillEntity>> = db.billDao().getRecentBills()

    fun getBillsBetween(start: Long, end: Long): Flow<List<BillEntity>> {
        return db.billDao().getBillsBetween(start, end)
    }

    suspend fun getBillById(id: Long): BillEntity? = withContext(Dispatchers.IO) {
        db.billDao().getBillById(id)
    }

    suspend fun getBillItems(billId: Long): List<BillItemEntity> = withContext(Dispatchers.IO) {
        db.billItemDao().getItemsForBill(billId)
    }

    suspend fun createBill(
        bill: BillEntity,
        items: List<BillItemEntity>
    ): Long = withContext(Dispatchers.IO) {
        db.withTransaction {
            val billId = db.billDao().insertBill(bill)
            val itemsWithBillId = items.map { it.copy(billId = billId) }
            db.billItemDao().insertAll(itemsWithBillId)

            // Deduct stock for each item & record movement
            for (item in items) {
                db.productDao().adjustStock(item.productId, -item.quantity)
                db.stockMovementDao().insertMovement(
                    StockMovementEntity(
                        productId = item.productId,
                        productName = item.productName,
                        changeQuantity = -item.quantity,
                        type = "SALE",
                        reason = "Bill #${bill.billNumber}"
                    )
                )
            }

            // If customer credit or balance due, add to customer ledger
            if (bill.customerId != null && bill.balanceDue > 0) {
                db.customerLedgerDao().insertEntry(
                    CustomerLedgerEntryEntity(
                        customerId = bill.customerId,
                        billId = billId,
                        type = "DEBIT",
                        amount = bill.balanceDue,
                        description = "Credit Bill #${bill.billNumber}"
                    )
                )
            }

            billId
        }
    }

    suspend fun returnOrCancelBill(billId: Long, reason: String) = withContext(Dispatchers.IO) {
        db.withTransaction {
            val bill = db.billDao().getBillById(billId) ?: return@withTransaction
            if (bill.billStatus == "CANCELLED" || bill.billStatus == "RETURNED") return@withTransaction

            val items = db.billItemDao().getItemsForBill(billId)
            // Restore inventory
            for (item in items) {
                db.productDao().adjustStock(item.productId, item.quantity)
                db.stockMovementDao().insertMovement(
                    StockMovementEntity(
                        productId = item.productId,
                        productName = item.productName,
                        changeQuantity = item.quantity,
                        type = "RETURN",
                        reason = "Cancelled Bill #${bill.billNumber}: $reason"
                    )
                )
            }

            // Reverse customer ledger entry if credit was added
            if (bill.customerId != null && bill.balanceDue > 0) {
                db.customerLedgerDao().insertEntry(
                    CustomerLedgerEntryEntity(
                        customerId = bill.customerId,
                        billId = billId,
                        type = "CREDIT",
                        amount = bill.balanceDue,
                        description = "Cancelled Bill Reversal #${bill.billNumber}"
                    )
                )
            }

            db.billDao().updateBillStatus(billId, "CANCELLED")
        }
    }

    // Expenses
    val allExpenses: Flow<List<ExpenseEntity>> = db.expenseDao().getAllExpenses()

    fun getExpensesBetween(start: Long, end: Long): Flow<List<ExpenseEntity>> {
        return db.expenseDao().getExpensesBetween(start, end)
    }

    suspend fun saveExpense(expense: ExpenseEntity): Long = withContext(Dispatchers.IO) {
        db.expenseDao().insertExpense(expense)
    }

    suspend fun deleteExpense(expense: ExpenseEntity) = withContext(Dispatchers.IO) {
        db.expenseDao().deleteExpense(expense)
    }

    // Settings
    val settings: Flow<ShopSettingsEntity?> = db.shopSettingsDao().getSettings()

    suspend fun getSettingsOnce(): ShopSettingsEntity = withContext(Dispatchers.IO) {
        db.shopSettingsDao().getSettingsOnce() ?: ShopSettingsEntity()
    }

    suspend fun saveSettings(settings: ShopSettingsEntity) = withContext(Dispatchers.IO) {
        db.shopSettingsDao().saveSettings(settings)
    }

    // Reports & Financial calculation
    suspend fun calculateFinancialReport(startTime: Long, endTime: Long): FinancialReport = withContext(Dispatchers.IO) {
        val bills = db.billDao().getBillsBetween(startTime, endTime).first().filter { it.billStatus == "COMPLETED" }
        val expenses = db.expenseDao().getExpensesBetween(startTime, endTime).first()

        val totalSales = bills.sumOf { it.grandTotal }
        val collectedCash = bills.sumOf { it.amountPaid }
        val creditSales = bills.sumOf { it.balanceDue }
        val totalExpenses = expenses.sumOf { it.amount }

        var totalCogs = 0.0
        for (bill in bills) {
            val items = db.billItemDao().getItemsForBill(bill.id)
            totalCogs += items.sumOf { it.unitCostSnapshot * it.quantity }
        }

        val grossProfit = totalSales - totalCogs
        val netProfit = grossProfit - totalExpenses

        FinancialReport(
            totalSales = totalSales,
            cogs = totalCogs,
            grossProfit = grossProfit,
            totalExpenses = totalExpenses,
            netProfit = netProfit,
            collectedCash = collectedCash,
            creditSales = creditSales,
            billsCount = bills.size
        )
    }

    suspend fun resetDatabase() = withContext(Dispatchers.IO) {
        db.withTransaction {
            db.billItemDao().deleteAll()
            db.billDao().deleteAll()
            db.customerLedgerDao().deleteAll()
            db.customerDao().deleteAll()
            db.supplierLedgerDao().deleteAll()
            db.supplierDao().deleteAll()
            db.purchaseItemDao().deleteAll()
            db.purchaseDao().deleteAll()
            db.expenseDao().deleteAll()
            db.stockMovementDao().deleteAll()
            db.productDao().deleteAll()
            AppDatabase.seedDefaultData(db)
        }
    }
}
