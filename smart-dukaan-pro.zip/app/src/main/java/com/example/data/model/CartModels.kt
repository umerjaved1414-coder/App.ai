package com.example.data.model

import com.example.data.local.entity.BillEntity
import com.example.data.local.entity.BillItemEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.ShopSettingsEntity
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class FinancialReport(
    val totalSales: Double,
    val cogs: Double,
    val grossProfit: Double,
    val totalExpenses: Double,
    val netProfit: Double,
    val collectedCash: Double,
    val creditSales: Double,
    val billsCount: Int
)

data class CartItem(
    val product: ProductEntity,
    var quantity: Double = 1.0,
    var unitPrice: Double = product.sellingPrice,
    var discount: Double = 0.0
) {
    val lineTotal: Double
        get() = (unitPrice * quantity) - discount
}

data class ReceiptData(
    val shopName: String,
    val ownerName: String,
    val phone: String,
    val address: String,
    val billNumber: String,
    val timestamp: Long,
    val customerName: String,
    val items: List<BillItemEntity>,
    val subtotal: Double,
    val discount: Double,
    val grandTotal: Double,
    val amountPaid: Double,
    val balanceDue: Double,
    val paymentMethod: String,
    val footerMessage: String
) {
    fun formatReceiptText(): String {
        val sdf = SimpleDateFormat("dd-MMM-yyyy hh:mm a", Locale.getDefault())
        val dateStr = sdf.format(Date(timestamp))

        val sb = StringBuilder()
        sb.append("================================\n")
        sb.append("      ${shopName.uppercase()}\n")
        if (address.isNotBlank()) sb.append("   $address\n")
        if (phone.isNotBlank()) sb.append("   Tel/WhatsApp: $phone\n")
        sb.append("================================\n")
        sb.append("Bill #: $billNumber\n")
        sb.append("Date:   $dateStr\n")
        if (customerName.isNotBlank() && customerName != "Walk-in Customer") {
            sb.append("Grahak: $customerName\n")
        }
        sb.append("--------------------------------\n")
        sb.append(String.format("%-16s %4s %6s %6s\n", "Item", "Qty", "Rate", "Total"))
        sb.append("--------------------------------\n")

        for (item in items) {
            val shortName = if (item.productName.length > 16) {
                item.productName.substring(0, 14) + ".."
            } else {
                item.productName
            }
            sb.append(
                String.format(
                    Locale.US,
                    "%-16s %4.1f %6.0f %6.0f\n",
                    shortName,
                    item.quantity,
                    item.unitPriceSnapshot,
                    item.totalPrice
                )
            )
        }

        sb.append("--------------------------------\n")
        sb.append(String.format(Locale.US, "%-22s: Rs. %8.0f\n", "Subtotal", subtotal))
        if (discount > 0) {
            sb.append(String.format(Locale.US, "%-22s: Rs. %8.0f\n", "Discount (Riyayat)", discount))
        }
        sb.append(String.format(Locale.US, "%-22s: Rs. %8.0f\n", "GRAND TOTAL (Kul)", grandTotal))
        sb.append(String.format(Locale.US, "%-22s: Rs. %8.0f\n", "Wasool (Received)", amountPaid))
        if (balanceDue > 0) {
            sb.append(String.format(Locale.US, "%-22s: Rs. %8.0f\n", "BAQI UDHAR (Due)", balanceDue))
        } else if (amountPaid > grandTotal) {
            val change = amountPaid - grandTotal
            sb.append(String.format(Locale.US, "%-22s: Rs. %8.0f\n", "Change Returned", change))
        }
        sb.append("Payment: $paymentMethod\n")
        sb.append("================================\n")
        if (footerMessage.isNotBlank()) {
            sb.append("   $footerMessage\n")
        }
        sb.append("   Powered by Smart Dukaan Pro\n")
        sb.append("================================\n")

        return sb.toString()
    }
}

object CurrencyFormatter {
    fun formatPkr(amount: Double, prefix: String = "Rs."): String {
        val formatter = NumberFormat.getNumberInstance(Locale.US)
        formatter.maximumFractionDigits = 1
        formatter.minimumFractionDigits = 0
        return "$prefix ${formatter.format(amount)}"
    }
}
