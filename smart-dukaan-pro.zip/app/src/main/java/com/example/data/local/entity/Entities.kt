package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "products",
    indices = [
        Index(value = ["barcode"], unique = false),
        Index(value = ["name"])
    ]
)
data class ProductEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val urduName: String = "",
    val barcode: String = "",
    val category: String = "General",
    val unit: String = "Piece", // Piece, Packet, Kg, Gram, Liter, Dozen
    val costPrice: Double,
    val sellingPrice: Double,
    val currentStock: Double,
    val minStockThreshold: Double = 5.0,
    val expiryDate: String = "",
    val supplierName: String = "",
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "customers",
    indices = [
        Index(value = ["name"]),
        Index(value = ["phone"])
    ]
)
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val phone: String = "",
    val address: String = "",
    val openingBalance: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis(),
    val isArchived: Boolean = false
)

@Entity(
    tableName = "customer_ledger",
    foreignKeys = [
        ForeignKey(
            entity = CustomerEntity::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["customerId"]),
        Index(value = ["timestamp"])
    ]
)
data class CustomerLedgerEntryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val customerId: Long,
    val billId: Long? = null,
    val type: String, // DEBIT (Udhar/Sale), CREDIT (Jama/Payment), ADJUSTMENT
    val amount: Double,
    val description: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "suppliers",
    indices = [
        Index(value = ["name"])
    ]
)
data class SupplierEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val phone: String = "",
    val address: String = "",
    val openingBalance: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "supplier_ledger",
    foreignKeys = [
        ForeignKey(
            entity = SupplierEntity::class,
            parentColumns = ["id"],
            childColumns = ["supplierId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["supplierId"])
    ]
)
data class SupplierLedgerEntryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val supplierId: Long,
    val purchaseId: Long? = null,
    val type: String, // PAYABLE (Purchase), PAID (Payment), ADJUSTMENT
    val amount: Double,
    val description: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "bills",
    indices = [
        Index(value = ["billNumber"], unique = true),
        Index(value = ["customerId"]),
        Index(value = ["timestamp"])
    ]
)
data class BillEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val billNumber: String,
    val customerId: Long? = null,
    val customerName: String = "",
    val subtotal: Double,
    val discountAmount: Double = 0.0,
    val grandTotal: Double,
    val amountPaid: Double,
    val balanceDue: Double,
    val paymentMethod: String = "CASH", // CASH, KHATA, PARTIAL
    val paymentStatus: String = "PAID", // PAID, PARTIAL, UNPAID
    val billStatus: String = "COMPLETED", // COMPLETED, CANCELLED, RETURNED
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "bill_items",
    foreignKeys = [
        ForeignKey(
            entity = BillEntity::class,
            parentColumns = ["id"],
            childColumns = ["billId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["billId"]),
        Index(value = ["productId"])
    ]
)
data class BillItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val billId: Long,
    val productId: Long,
    val productName: String,
    val productUrduName: String = "",
    val unit: String = "Piece",
    val unitCostSnapshot: Double, // Cost at sale time for accurate COGS
    val unitPriceSnapshot: Double, // Selling price at sale time
    val quantity: Double,
    val discount: Double = 0.0,
    val totalPrice: Double
)

@Entity(
    tableName = "purchases",
    indices = [
        Index(value = ["supplierId"]),
        Index(value = ["timestamp"])
    ]
)
data class PurchaseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val invoiceNumber: String,
    val supplierId: Long? = null,
    val supplierName: String = "",
    val totalAmount: Double,
    val amountPaid: Double,
    val balanceDue: Double,
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "purchase_items",
    foreignKeys = [
        ForeignKey(
            entity = PurchaseEntity::class,
            parentColumns = ["id"],
            childColumns = ["purchaseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["purchaseId"])
    ]
)
data class PurchaseItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val purchaseId: Long,
    val productId: Long,
    val productName: String,
    val quantity: Double,
    val unitCost: Double,
    val totalCost: Double
)

@Entity(
    tableName = "expenses",
    indices = [
        Index(value = ["category"]),
        Index(value = ["timestamp"])
    ]
)
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val category: String, // Shop Rent, Electricity, Staff Salary, Transport, Packaging, Tea/Food, Other
    val amount: Double,
    val paymentMethod: String = "Cash",
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "stock_movements",
    indices = [
        Index(value = ["productId"]),
        Index(value = ["timestamp"])
    ]
)
data class StockMovementEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val productId: Long,
    val productName: String,
    val changeQuantity: Double, // + or -
    val type: String, // SALE, PURCHASE, RETURN, DAMAGE, EXPIRY, CORRECTION
    val reason: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "shop_settings")
data class ShopSettingsEntity(
    @PrimaryKey
    val id: Int = 1,
    val shopName: String = "Bismillah Kiryana Store",
    val ownerName: String = "Muhammad Ali",
    val phone: String = "0300-1234567",
    val address: String = "Main Bazar, Lahore",
    val currencySymbol: String = "Rs.",
    val language: String = "ROMAN_URDU", // ROMAN_URDU, URDU, ENGLISH
    val receiptFooter: String = "Shukriya! Dobara Tashreef Layen.",
    val defaultLowStockThreshold: Double = 5.0,
    val allowNegativeStock: Boolean = false
)
