package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.SupplierEntity
import com.example.data.model.CurrencyFormatter
import com.example.ui.DukaanViewModel
import com.example.ui.theme.DukaanGreenPrimary
import com.example.ui.theme.DukaanRedAlert

@Composable
fun SuppliersScreen(
    viewModel: DukaanViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val suppliers by viewModel.allSuppliers.collectAsState()
    val allProducts by viewModel.allProducts.collectAsState()

    var showAddSupplierDialog by remember { mutableStateOf(false) }
    var showRecordPurchaseDialog by remember { mutableStateOf(false) }
    var showPaymentDialog by remember { mutableStateOf(false) }
    var selectedSupplierForAction by remember { mutableStateOf<SupplierEntity?>(null) }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Sppliers & Khareedari (خریداری)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "Record incoming inventory and wholesale dues",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                        Button(
                            onClick = { showRecordPurchaseDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = DukaanGreenPrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("New Purchase", fontSize = 11.sp)
                        }
                    }
                }
            }

            if (suppliers.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.LocalShipping,
                            contentDescription = null,
                            tint = Color.LightGray,
                            modifier = Modifier.size(54.dp)
                        )
                        Text(
                            text = "Koi Supplier darj nahi hai\n(Tap '+' to add supplier/dealer)",
                            textAlign = TextAlign.Center,
                            color = Color.Gray,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(suppliers, key = { it.id }) { supplier ->
                        SupplierCard(
                            supplier = supplier,
                            onPay = {
                                selectedSupplierForAction = supplier
                                showPaymentDialog = true
                            }
                        )
                    }
                }
            }
        }

        // FAB: Add Supplier
        FloatingActionButton(
            onClick = { showAddSupplierDialog = true },
            containerColor = DukaanGreenPrimary,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Supplier")
        }
    }

    if (showAddSupplierDialog) {
        AddSupplierDialog(
            onDismiss = { showAddSupplierDialog = false },
            onSave = { name, phone, address, openBal ->
                viewModel.addSupplier(name, phone, address, openBal) {
                    showAddSupplierDialog = false
                    Toast.makeText(context, "Supplier darj hogaya", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    if (showRecordPurchaseDialog) {
        RecordPurchaseDialog(
            suppliers = suppliers,
            products = allProducts,
            onDismiss = { showRecordPurchaseDialog = false },
            onConfirm = { supId, supName, inv, prodId, prodName, qty, unitCost, paid ->
                viewModel.recordPurchase(supId, supName, inv, prodId, prodName, qty, unitCost, paid) {
                    showRecordPurchaseDialog = false
                    Toast.makeText(context, "Khareedari darj hogayi aur Stock barh gaya!", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    if (showPaymentDialog && selectedSupplierForAction != null) {
        PaySupplierDialog(
            supplier = selectedSupplierForAction!!,
            onDismiss = { showPaymentDialog = false },
            onConfirm = { amount, notes ->
                viewModel.recordSupplierPayment(selectedSupplierForAction!!.id, amount, notes) {
                    showPaymentDialog = false
                    Toast.makeText(context, "Payment darj hogayi", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }
}

@Composable
fun SupplierCard(
    supplier: SupplierEntity,
    onPay: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color(0xFFFFF3CD), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.LocalShipping, contentDescription = null, tint = Color(0xFF664D03), modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(text = supplier.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    if (supplier.phone.isNotBlank()) {
                        Text(text = "Tel: ${supplier.phone}", fontSize = 11.sp, color = Color.Gray)
                    }
                    if (supplier.address.isNotBlank()) {
                        Text(text = supplier.address, fontSize = 10.sp, color = Color.Gray)
                    }
                }
            }

            OutlinedButton(
                onClick = onPay,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(34.dp)
            ) {
                Text("Pay Supplier", fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun AddSupplierDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, String, Double) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var openingBal by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Naya Supplier Darj Karein", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DukaanGreenPrimary)
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Supplier / Agency Naam *") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Address / Mandi Location") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = openingBal,
                    onValueChange = { openingBal = it },
                    label = { Text("Sabqa Dena / Opening Balance (Rs.)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = {
                            if (name.isBlank()) return@Button
                            val bal = openingBal.toDoubleOrNull() ?: 0.0
                            onSave(name.trim(), phone.trim(), address.trim(), bal)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = DukaanGreenPrimary),
                        enabled = name.isNotBlank()
                    ) {
                        Text("Save")
                    }
                }
            }
        }
    }
}

@Composable
fun RecordPurchaseDialog(
    suppliers: List<SupplierEntity>,
    products: List<ProductEntity>,
    onDismiss: () -> Unit,
    onConfirm: (Long?, String, String, Long, String, Double, Double, Double) -> Unit
) {
    var selectedSupplier by remember { mutableStateOf<SupplierEntity?>(suppliers.firstOrNull()) }
    var selectedProduct by remember { mutableStateOf<ProductEntity?>(products.firstOrNull()) }
    var invoiceNumber by remember { mutableStateOf("") }
    var quantityText by remember { mutableStateOf("10") }
    var unitCostText by remember { mutableStateOf(selectedProduct?.costPrice?.toString() ?: "100") }
    var amountPaidText by remember { mutableStateOf("") }

    var showSupMenu by remember { mutableStateOf(false) }
    var showProdMenu by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Khareedari Darj Karein (Purchase Stock)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DukaanGreenPrimary)
                Spacer(modifier = Modifier.height(10.dp))

                // Supplier picker
                Box {
                    OutlinedButton(
                        onClick = { showSupMenu = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(selectedSupplier?.name ?: "Supplier Chunein (Optional)")
                    }
                    DropdownMenu(expanded = showSupMenu, onDismissRequest = { showSupMenu = false }) {
                        for (s in suppliers) {
                            DropdownMenuItem(text = { Text(s.name) }, onClick = { selectedSupplier = s; showSupMenu = false })
                        }
                    }
                }

                // Product picker
                Box(modifier = Modifier.padding(top = 8.dp)) {
                    OutlinedButton(
                        onClick = { showProdMenu = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Saman: ${selectedProduct?.name ?: "Select Product"}")
                    }
                    DropdownMenu(expanded = showProdMenu, onDismissRequest = { showProdMenu = false }) {
                        for (p in products) {
                            DropdownMenuItem(
                                text = { Text("${p.name} (Mojooda: ${p.currentStock})") },
                                onClick = {
                                    selectedProduct = p
                                    unitCostText = p.costPrice.toString()
                                    showProdMenu = false
                                }
                            )
                        }
                    }
                }

                Row(modifier = Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it },
                        label = { Text("Tedad (Qty) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = unitCostText,
                        onValueChange = { unitCostText = it },
                        label = { Text("Khareed Rate *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                val qty = quantityText.toDoubleOrNull() ?: 0.0
                val cost = unitCostText.toDoubleOrNull() ?: 0.0
                val totalCost = qty * cost

                Text(
                    text = "Total Khareed Rakam: ${CurrencyFormatter.formatPkr(totalCost)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = DukaanGreenPrimary,
                    modifier = Modifier.padding(top = 6.dp)
                )

                OutlinedTextField(
                    value = amountPaidText,
                    onValueChange = { amountPaidText = it },
                    label = { Text("Ada Shuda Rakam (Amount Paid) *") },
                    placeholder = { Text("e.g. ${totalCost.toInt()}") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = {
                            if (selectedProduct == null || qty <= 0 || cost <= 0) return@Button
                            val paid = amountPaidText.toDoubleOrNull() ?: totalCost
                            onConfirm(
                                selectedSupplier?.id,
                                selectedSupplier?.name ?: "Direct Market",
                                invoiceNumber,
                                selectedProduct!!.id,
                                selectedProduct!!.name,
                                qty,
                                cost,
                                paid
                            )
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = DukaanGreenPrimary),
                        enabled = selectedProduct != null && qty > 0 && cost > 0
                    ) {
                        Text("Add Stock")
                    }
                }
            }
        }
    }
}

@Composable
fun PaySupplierDialog(
    supplier: SupplierEntity,
    onDismiss: () -> Unit,
    onConfirm: (Double, String) -> Unit
) {
    var amountText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("Bank / Cash Transfer") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Supplier Ko Adaigi (Pay Supplier)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Supplier: ${supplier.name}", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 2.dp))
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Rakam (Amount in Rs.) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Tafseel / Reference") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = {
                            val amt = amountText.toDoubleOrNull() ?: 0.0
                            if (amt > 0) onConfirm(amt, notes)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = DukaanGreenPrimary),
                        enabled = (amountText.toDoubleOrNull() ?: 0.0) > 0
                    ) {
                        Text("Save")
                    }
                }
            }
        }
    }
}
