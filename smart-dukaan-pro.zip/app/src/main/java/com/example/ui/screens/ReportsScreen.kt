package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CurrencyFormatter
import com.example.data.model.FinancialReport
import com.example.ui.DukaanViewModel
import com.example.ui.theme.DukaanGold
import com.example.ui.theme.DukaanGreenPrimary
import com.example.ui.theme.DukaanRedAlert

@Composable
fun ReportsScreen(
    viewModel: DukaanViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val report by viewModel.financialReport.collectAsState()
    val selectedRange by viewModel.reportDateRange.collectAsState()
    val allProducts by viewModel.allProducts.collectAsState()
    val totalCredit by viewModel.totalOutstandingCredit.collectAsState()
    val settings by viewModel.settings.collectAsState()

    LaunchedEffect(selectedRange) {
        viewModel.refreshReports()
    }

    val ranges = listOf(
        Pair("TODAY", "Aaj (Today)"),
        Pair("YESTERDAY", "Guzashta Kal (Yesterday)"),
        Pair("THIS_WEEK", "Is Hafte (This Week)"),
        Pair("THIS_MONTH", "Is Maheene (This Month)"),
        Pair("ALL", "Kul Record (All Time)")
    )

    // Stock valuation calculation
    val stockValuationCost = remember(allProducts) {
        allProducts.sumOf { it.costPrice * it.currentStock.coerceAtLeast(0.0) }
    }
    val stockValuationRetail = remember(allProducts) {
        allProducts.sumOf { it.sellingPrice * it.currentStock.coerceAtLeast(0.0) }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Date Range Selector
        item {
            Surface(tonalElevation = 1.dp, shape = RoundedCornerShape(12.dp)) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "Waqt Chunein (Select Period):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    LazyRow(
                        modifier = Modifier.padding(top = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(ranges) { (key, label) ->
                            FilterChip(
                                selected = selectedRange == key,
                                onClick = { viewModel.setReportRange(key) },
                                label = { Text(label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = DukaanGreenPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
            }
        }

        // Main Profit & Loss Statement Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Munafa o Nuqsan (Profit & Loss)",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp
                        )
                        Box(
                            modifier = Modifier
                                .background(
                                    if (report.netProfit >= 0) Color(0xFFD1E7DD) else Color(0xFFF8D7DA),
                                    RoundedCornerShape(6.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (report.netProfit >= 0) "Munafa (Profit)" else "Nuqsan (Loss)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (report.netProfit >= 0) Color(0xFF0F5132) else Color(0xFF842029)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Line items
                    ReportLineItem(
                        label = "Kul Farokht (Gross Sales):",
                        amount = CurrencyFormatter.formatPkr(report.totalSales),
                        isBold = false
                    )
                    ReportLineItem(
                        label = "- Mal Ki Asal Laagat (COGS):",
                        amount = "- " + CurrencyFormatter.formatPkr(report.cogs),
                        amountColor = Color.Gray,
                        isBold = false
                    )

                    Divider(modifier = Modifier.padding(vertical = 8.dp))

                    ReportLineItem(
                        label = "= Kham Munafa (Gross Profit):",
                        amount = CurrencyFormatter.formatPkr(report.grossProfit),
                        amountColor = if (report.grossProfit >= 0) Color(0xFF0F5132) else DukaanRedAlert,
                        isBold = true
                    )

                    ReportLineItem(
                        label = "- Dukaan Ke Akhrajat (Expenses):",
                        amount = "- " + CurrencyFormatter.formatPkr(report.totalExpenses),
                        amountColor = DukaanRedAlert,
                        isBold = false
                    )

                    Divider(modifier = Modifier.padding(vertical = 8.dp))

                    // Net Profit Highlight
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "KHALIS MUNAFA (Net Profit):",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Estimated based on actual COGS snapshots",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }
                        Text(
                            text = CurrencyFormatter.formatPkr(report.netProfit),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (report.netProfit >= 0) DukaanGreenPrimary else DukaanRedAlert
                        )
                    }
                }
            }
        }

        // Cash Flow Breakdown
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Rakam Ki Wasooli (Cash vs Credit)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color(0xFFE8F5E9), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Column {
                                Text("Naqad Wasool", fontSize = 11.sp, color = Color(0xFF2E7D32))
                                Text(
                                    CurrencyFormatter.formatPkr(report.collectedCash),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color(0xFF2E7D32)
                                )
                            }
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color(0xFFF8D7DA), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Column {
                                Text("Udhar Farokht (Credit)", fontSize = 11.sp, color = DukaanRedAlert)
                                Text(
                                    CurrencyFormatter.formatPkr(report.creditSales),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = DukaanRedAlert
                                )
                            }
                        }
                    }
                }
            }
        }

        // Stock Valuation Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Inventory, contentDescription = null, tint = DukaanGold)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Dukaan Mal Ki Qeemat (Stock Valuation)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Khareed Laagat Par (At Cost Price):", fontSize = 12.sp)
                        Text(
                            CurrencyFormatter.formatPkr(stockValuationCost),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Farokht Qeemat Par (At Retail Value):", fontSize = 12.sp)
                        Text(
                            CurrencyFormatter.formatPkr(stockValuationRetail),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = DukaanGreenPrimary
                        )
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Matlooba Munafa (Potential Profit in Stock):", fontSize = 12.sp, color = Color.Gray)
                        Text(
                            CurrencyFormatter.formatPkr((stockValuationRetail - stockValuationCost).coerceAtLeast(0.0)),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = DukaanGold
                        )
                    }
                }
            }
        }

        // Share Report Button
        item {
            Button(
                onClick = {
                    val reportText = buildBusinessReportText(
                        shopName = settings?.shopName ?: "Smart Dukaan",
                        period = selectedRange,
                        report = report,
                        totalCredit = totalCredit,
                        stockCost = stockValuationCost
                    )
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "Business Report - ${settings?.shopName}")
                        putExtra(Intent.EXTRA_TEXT, reportText)
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Share Business Report"))
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = DukaanGreenPrimary),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                Text("Share Report on WhatsApp / Share Sheet")
            }
        }
    }
}

@Composable
fun ReportLineItem(
    label: String,
    amount: String,
    amountColor: Color = Color.Black,
    isBold: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal
        )
        Text(
            text = amount,
            fontSize = 13.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.SemiBold,
            color = amountColor
        )
    }
}

fun buildBusinessReportText(
    shopName: String,
    period: String,
    report: com.example.data.model.FinancialReport,
    totalCredit: Double,
    stockCost: Double
): String {
    val sb = StringBuilder()
    sb.append("================================\n")
    sb.append("   ${shopName.uppercase()} - REPORT\n")
    sb.append("   Period: $period\n")
    sb.append("================================\n")
    sb.append("Total Bills:      ${report.billsCount}\n")
    sb.append("Kul Farokht:      Rs. ${report.totalSales.toInt()}\n")
    sb.append("Mal Ki Laagat:    Rs. ${report.cogs.toInt()}\n")
    sb.append("Kham Munafa:      Rs. ${report.grossProfit.toInt()}\n")
    sb.append("Dukaan Akhrajat:  Rs. ${report.totalExpenses.toInt()}\n")
    sb.append("--------------------------------\n")
    sb.append("KHALIS MUNAFA:    Rs. ${report.netProfit.toInt()}\n")
    sb.append("--------------------------------\n")
    sb.append("Naqad Wasooli:    Rs. ${report.collectedCash.toInt()}\n")
    sb.append("Udhar Farokht:    Rs. ${report.creditSales.toInt()}\n")
    sb.append("Market Baqi Udhar:Rs. ${totalCredit.toInt()}\n")
    sb.append("Dukaan Stock Mal: Rs. ${stockCost.toInt()}\n")
    sb.append("================================\n")
    sb.append("Smart Dukaan Pro - Kiryana Manager\n")
    return sb.toString()
}
