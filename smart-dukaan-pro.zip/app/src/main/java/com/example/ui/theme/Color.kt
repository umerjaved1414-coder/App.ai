package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DukaanGreenDark = Color(0xFF0F5132)
val DukaanGreenPrimary = Color(0xFF146C43)
val DukaanGreenLight = Color(0xFF198754)
val DukaanGreenContainer = Color(0xFFD1E7DD)
val DukaanOnGreenContainer = Color(0xFF0A3622)

val DukaanGold = Color(0xFFB8860B)
val DukaanGoldLight = Color(0xFFFFF3CD)
val DukaanGoldDark = Color(0xFF664D03)

val DukaanRedAlert = Color(0xFFB02A37)
val DukaanRedLight = Color(0xFFF8D7DA)
val DukaanRedDark = Color(0xFF58151C)

val DukaanSurfaceLight = Color(0xFFF8F9FA)
val DukaanSurfaceCard = Color(0xFFFFFFFF)
val DukaanBorder = Color(0xFFDEE2E6)

val DukaanDarkBg = Color(0xFF121212)
val DukaanDarkSurface = Color(0xFF1E1E1E)
val DukaanDarkCard = Color(0xFF252525)
