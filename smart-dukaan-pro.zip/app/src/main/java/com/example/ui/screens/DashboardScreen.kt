package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.BillEntity
import com.example.data.model.CurrencyFormatter
import com.example.data.model.FinancialReport
import com.example.data.model.ReceiptData
import com.example.ui.DukaanViewModel
import com.example.ui.NavTab
import com.example.ui.components.ReceiptDialog
import com.example.ui.theme.DukaanGold
import com.example.ui.theme.DukaanGreenPrimary
import com.example.ui.theme.DukaanRedAlert
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@Composable
fun DashboardScreen(
    viewModel: DukaanViewModel,
    onNavigate: (NavTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsState()
    val todayFinancial by viewModel.todayFinancial.collectAsState()
    val totalCredit by viewModel.totalOutstandingCredit.collectAsState()
    val totalProducts by viewModel.totalProductCount.collectAsState()
    val lowStockCount by viewModel.lowStockCount.collectAsState()
    val recentBills by viewModel.recentBills.collectAsState()

    var viewBillReceipt by remember { mutableStateOf<ReceiptData?>(null) }

    LaunchedEffect(Unit) {
        viewModel.refreshReports()
    }

    val sdf = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault())
    sdf.timeZone = TimeZone.getTimeZone("Asia/Karachi")
    val todayDateStr = sdf.format(Date())

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Shop Welcome Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DukaanGreenPrimary)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = settings?.shopName ?: "Smart Dukaan Pro",
                                color = Color.White,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = todayDateStr,
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                        Box(
                            modifier = Modifier
                                .background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Offline Pro",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Primary Big Button for Billing
                    Button(
                        onClick = { onNavigate(NavTab.BILLING) },
                        colors = ButtonDefaults.buttonColors(containerColor = DukaanGold),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                    ) {
                        Icon(
                            Icons.Default.PointOfSale,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Text(
                            text = "+ NAYA BILL BANAYEN (نیا بل بنائیں)",
                            color = Color.Black,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }

        // Low stock warning banner if any items are low
        if (lowStockCount > 0) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3CD))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                Icons.Default.Warning,
                                contentDescription = "Alert",
                                tint = Color(0xFF664D03),
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "$lowStockCount Items Kam Stock Hain! (کم اسٹاک)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color(0xFF664D03)
                                )
                                Text(
                                    text = "Tap to review stock / نیا مال منگوائیں",
                                    fontSize = 11.sp,
                                    color = Color(0xFF664D03).copy(alpha = 0.8f)
                                )
                            }
                        }
                        OutlinedButton(
                            onClick = {
                                viewModel.productStockFilter.value = "Low Stock"
                                onNavigate(NavTab.PRODUCTS)
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Check", fontSize = 12.sp, color = Color(0xFF664D03))
                        }
                    }
                }
            }
        }

        // Quick Action Buttons
        item {
            Text(
                text = viewModel.tr("quick_actions"),
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionItem(
                    icon = Icons.Default.Add,
                    title = "Add Saman",
                    urdu = "سامان درج",
                    containerColor = Color(0xFFE8F5E9),
                    iconColor = DukaanGreenPrimary,
                    modifier = Modifier.weight(1f)
                ) {
                    onNavigate(NavTab.PRODUCTS)
                }
                QuickActionItem(
                    icon = Icons.Default.PersonAdd,
                    title = "Grahak Khata",
                    urdu = "گاہک کھاتہ",
                    containerColor = Color(0xFFE3F2FD),
                    iconColor = Color(0xFF1976D2),
                    modifier = Modifier.weight(1f)
                ) {
                    onNavigate(NavTab.KHATA)
                }
                QuickActionItem(
                    icon = Icons.Default.MoneyOff,
                    title = "Dukaan Kharcha",
                    urdu = "خرچہ درج",
                    containerColor = Color(0xFFFFEBEE),
                    iconColor = DukaanRedAlert,
                    modifier = Modifier.weight(1f)
                ) {
                    onNavigate(NavTab.EXPENSES)
                }
            }
        }

        // Today's Performance KPI Grid
        item {
            Text(
                text = "Aaj Ki Kar-kardagi (Today's Summary)",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = viewModel.tr("today_sales"),
                        amount = CurrencyFormatter.formatPkr(todayFinancial.totalSales),
                        subtitle = "${todayFinancial.billsCount} Bills aaj bne",
                        icon = Icons.Default.PointOfSale,
                        iconTint = DukaanGreenPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = viewModel.tr("collected_cash"),
                        amount = CurrencyFormatter.formatPkr(todayFinancial.collectedCash),
                        subtitle = "Naqad jama hua",
                        icon = Icons.Default.AccountBalanceWallet,
                        iconTint = Color(0xFF2E7D32),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = viewModel.tr("est_profit"),
                        amount = CurrencyFormatter.formatPkr(todayFinancial.netProfit),
                        subtitle = "Gross: ${CurrencyFormatter.formatPkr(todayFinancial.grossProfit)}",
                        icon = Icons.Default.TrendingUp,
                        iconTint = Color(0xFF0D6EFD),
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = viewModel.tr("today_expenses"),
                        amount = CurrencyFormatter.formatPkr(todayFinancial.totalExpenses),
                        subtitle = "Shop daily cost",
                        icon = Icons.Default.MoneyOff,
                        iconTint = DukaanRedAlert,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = viewModel.tr("customer_credit"),
                        amount = CurrencyFormatter.formatPkr(totalCredit),
                        subtitle = "Market se lena hai",
                        icon = Icons.Default.ReceiptLong,
                        iconTint = Color(0xFFC0392B),
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = viewModel.tr("total_stock_items"),
                        amount = "$totalProducts Products",
                        subtitle = "$lowStockCount items low",
                        icon = Icons.Default.Inventory,
                        iconTint = Color(0xFF495057),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Recent Bills Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = viewModel.tr("recent_bills"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = "View Reports →",
                    fontSize = 13.sp,
                    color = DukaanGreenPrimary,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { onNavigate(NavTab.REPORTS) }
                )
            }
        }

        if (recentBills.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Abhi tak koi bill nahi bana\n(No bills created yet)",
                            textAlign = TextAlign.Center,
                            color = Color.Gray,
                            fontSize = 13.sp
                        )
                        Button(
                            onClick = { onNavigate(NavTab.BILLING) },
                            modifier = Modifier.padding(top = 10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DukaanGreenPrimary)
                        ) {
                            Text("Create First Bill")
                        }
                    }
                }
            }
        } else {
            items(recentBills) { bill ->
                RecentBillCard(bill = bill, viewModel = viewModel) {
                    // Show receipt dialog
                    viewBillReceipt = it
                }
            }
        }
    }

    viewBillReceipt?.let { receipt ->
        ReceiptDialog(receipt = receipt) {
            viewBillReceipt = null
        }
    }
}

@Composable
fun QuickActionItem(
    icon: ImageVector,
    title: String,
    urdu: String,
    containerColor: Color,
    iconColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
            )
            Text(
                text = urdu,
                fontSize = 10.sp,
                color = Color.DarkGray,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    amount: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    color = Color.DarkGray,
                    fontWeight = FontWeight.Medium
                )
                Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = amount,
                fontSize = 17.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = Color.Gray,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

@Composable
fun RecentBillCard(
    bill: BillEntity,
    viewModel: DukaanViewModel,
    onViewReceipt: (ReceiptData) -> Unit
) {
    val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
    val dateStr = sdf.format(Date(bill.timestamp))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                viewModel.loadBillReceipt(bill) { receipt ->
                    onViewReceipt(receipt)
                }
            },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = bill.billNumber,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .background(
                                if (bill.paymentStatus == "PAID") Color(0xFFD1E7DD) else Color(0xFFF8D7DA),
                                RoundedCornerShape(4.dp)
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (bill.paymentStatus == "PAID") "Naqad (Cash)" else "Udhar (Credit)",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (bill.paymentStatus == "PAID") Color(0xFF0F5132) else Color(0xFF842029)
                        )
                    }
                }
                Text(
                    text = "${bill.customerName} • $dateStr",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = CurrencyFormatter.formatPkr(bill.grandTotal),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    color = DukaanGreenPrimary
                )
                Text(
                    text = "Receipt →",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }
        }
    }
}
