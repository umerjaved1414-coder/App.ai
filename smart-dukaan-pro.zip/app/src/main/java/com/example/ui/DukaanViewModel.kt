package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.BillEntity
import com.example.data.local.entity.BillItemEntity
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.CustomerLedgerEntryEntity
import com.example.data.local.entity.ExpenseEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.local.entity.PurchaseEntity
import com.example.data.local.entity.PurchaseItemEntity
import com.example.data.local.entity.ShopSettingsEntity
import com.example.data.local.entity.SupplierEntity
import com.example.data.model.AppLanguage
import com.example.data.model.CartItem
import com.example.data.model.FinancialReport
import com.example.data.model.Localization
import com.example.data.model.ReceiptData
import com.example.data.repository.DukaanRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

enum class NavTab {
    HOME,
    BILLING,
    PRODUCTS,
    KHATA,
    REPORTS,
    EXPENSES,
    SUPPLIERS,
    SETTINGS
}

data class CustomerWithBalance(
    val customer: CustomerEntity,
    val balance: Double
)

class DukaanViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val repository = DukaanRepository(db)

    // Current Navigation Tab
    private val _currentTab = MutableStateFlow(NavTab.HOME)
    val currentTab: StateFlow<NavTab> = _currentTab.asStateFlow()

    fun navigateTo(tab: NavTab) {
        _currentTab.value = tab
    }

    // Settings & Language
    val settings = repository.settings.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        ShopSettingsEntity()
    )

    private val _language = MutableStateFlow(AppLanguage.ROMAN_URDU)
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    init {
        viewModelScope.launch {
            repository.settings.collect { s ->
                s?.let {
                    _language.value = when (it.language) {
                        "URDU" -> AppLanguage.URDU
                        "ENGLISH" -> AppLanguage.ENGLISH
                        else -> AppLanguage.ROMAN_URDU
                    }
                }
            }
        }
        refreshReports()
    }

    fun tr(key: String): String = Localization.tr(key, _language.value)

    fun setLanguage(lang: AppLanguage) {
        _language.value = lang
        viewModelScope.launch {
            val current = repository.getSettingsOnce()
            repository.saveSettings(current.copy(language = lang.name))
        }
    }

    // ------------------------------------------------------------------------
    // POS / BILLING CART STATE
    // ------------------------------------------------------------------------
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

    val billDiscount = MutableStateFlow(0.0)
    val amountReceivedInput = MutableStateFlow("")
    val selectedCustomer = MutableStateFlow<CustomerEntity?>(null)
    val paymentMethod = MutableStateFlow("CASH") // CASH, KHATA, PARTIAL
    val billNotes = MutableStateFlow("")

    private val _lastCompletedReceipt = MutableStateFlow<ReceiptData?>(null)
    val lastCompletedReceipt: StateFlow<ReceiptData?> = _lastCompletedReceipt.asStateFlow()

    val cartSubtotal: StateFlow<Double> = _cartItems.combine(billDiscount) { items, _ ->
        items.sumOf { it.lineTotal }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val cartGrandTotal: StateFlow<Double> = combine(cartSubtotal, billDiscount) { sub, disc ->
        (sub - disc).coerceAtLeast(0.0)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun addToCart(product: ProductEntity) {
        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == product.id }
        if (index >= 0) {
            val existing = current[index]
            current[index] = existing.copy(quantity = existing.quantity + 1.0)
        } else {
            current.add(CartItem(product = product, quantity = 1.0, unitPrice = product.sellingPrice))
        }
        _cartItems.value = current
    }

    fun updateCartItemQuantity(productId: Long, newQty: Double) {
        if (newQty <= 0) {
            removeFromCart(productId)
            return
        }
        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == productId }
        if (index >= 0) {
            current[index] = current[index].copy(quantity = newQty)
            _cartItems.value = current
        }
    }

    fun updateCartItemPrice(productId: Long, newPrice: Double) {
        if (newPrice < 0) return
        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == productId }
        if (index >= 0) {
            current[index] = current[index].copy(unitPrice = newPrice)
            _cartItems.value = current
        }
    }

    fun removeFromCart(productId: Long) {
        _cartItems.value = _cartItems.value.filter { it.product.id != productId }
    }

    fun clearCart() {
        _cartItems.value = emptyList()
        billDiscount.value = 0.0
        amountReceivedInput.value = ""
        selectedCustomer.value = null
        paymentMethod.value = "CASH"
        billNotes.value = ""
    }

    fun completeSale(onSuccess: (ReceiptData) -> Unit, onError: (String) -> Unit) {
        val items = _cartItems.value
        if (items.isEmpty()) {
            onError("Cart is empty / Bill mein koi saman nahi hai")
            return
        }

        val subtotal = items.sumOf { it.lineTotal }
        val discount = billDiscount.value
        val grandTotal = (subtotal - discount).coerceAtLeast(0.0)
        val enteredReceived = amountReceivedInput.value.toDoubleOrNull() ?: 0.0

        val customer = selectedCustomer.value
        val method = paymentMethod.value

        var amountPaid = 0.0
        var balanceDue = 0.0

        when (method) {
            "CASH" -> {
                amountPaid = grandTotal
                balanceDue = 0.0
            }
            "KHATA" -> {
                if (customer == null) {
                    onError("Khata sale ke liye Grahak chunein (Select a customer for Credit sale)")
                    return
                }
                amountPaid = 0.0
                balanceDue = grandTotal
            }
            "PARTIAL" -> {
                if (customer == null) {
                    onError("Partial payment ke liye Grahak chunein (Select customer for credit balance)")
                    return
                }
                amountPaid = enteredReceived.coerceAtMost(grandTotal)
                balanceDue = (grandTotal - amountPaid).coerceAtLeast(0.0)
            }
        }

        val status = if (balanceDue <= 0) "PAID" else if (amountPaid > 0) "PARTIAL" else "UNPAID"
        val billNum = "SD-${System.currentTimeMillis() % 100000}"

        viewModelScope.launch {
            try {
                val bill = BillEntity(
                    billNumber = billNum,
                    customerId = customer?.id,
                    customerName = customer?.name ?: "Walk-in Customer",
                    subtotal = subtotal,
                    discountAmount = discount,
                    grandTotal = grandTotal,
                    amountPaid = amountPaid,
                    balanceDue = balanceDue,
                    paymentMethod = method,
                    paymentStatus = status,
                    billStatus = "COMPLETED",
                    notes = billNotes.value,
                    timestamp = System.currentTimeMillis()
                )

                val billItems = items.map {
                    BillItemEntity(
                        billId = 0L,
                        productId = it.product.id,
                        productName = it.product.name,
                        productUrduName = it.product.urduName,
                        unit = it.product.unit,
                        unitCostSnapshot = it.product.costPrice,
                        unitPriceSnapshot = it.unitPrice,
                        quantity = it.quantity,
                        discount = it.discount,
                        totalPrice = it.lineTotal
                    )
                }

                repository.createBill(bill, billItems)

                val shopConfig = repository.getSettingsOnce()
                val receipt = ReceiptData(
                    shopName = shopConfig.shopName,
                    ownerName = shopConfig.ownerName,
                    phone = shopConfig.phone,
                    address = shopConfig.address,
                    billNumber = billNum,
                    timestamp = bill.timestamp,
                    customerName = bill.customerName,
                    items = billItems,
                    subtotal = subtotal,
                    discount = discount,
                    grandTotal = grandTotal,
                    amountPaid = amountPaid,
                    balanceDue = balanceDue,
                    paymentMethod = method,
                    footerMessage = shopConfig.receiptFooter
                )

                _lastCompletedReceipt.value = receipt
                clearCart()
                refreshReports()
                onSuccess(receipt)
            } catch (e: Exception) {
                onError(e.message ?: "Failed to save bill")
            }
        }
    }

    fun dismissReceiptDialog() {
        _lastCompletedReceipt.value = null
    }

    fun loadBillReceipt(bill: BillEntity, onReceipt: (ReceiptData) -> Unit) {
        viewModelScope.launch {
            val items = repository.getBillItems(bill.id)
            val shop = repository.getSettingsOnce()
            val receipt = ReceiptData(
                shopName = shop.shopName,
                ownerName = shop.ownerName,
                phone = shop.phone,
                address = shop.address,
                billNumber = bill.billNumber,
                timestamp = bill.timestamp,
                customerName = bill.customerName,
                items = items,
                subtotal = bill.subtotal,
                discount = bill.discountAmount,
                grandTotal = bill.grandTotal,
                amountPaid = bill.amountPaid,
                balanceDue = bill.balanceDue,
                paymentMethod = bill.paymentMethod,
                footerMessage = shop.receiptFooter
            )
            onReceipt(receipt)
        }
    }

    // ------------------------------------------------------------------------
    // PRODUCTS MANAGEMENT
    // ------------------------------------------------------------------------
    val productSearchQuery = MutableStateFlow("")
    val productCategoryFilter = MutableStateFlow("All")
    val productStockFilter = MutableStateFlow("All") // "All", "Low Stock", "Out of Stock"

    val allProducts = repository.allProducts.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val lowStockCount = repository.lowStockCount.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        0
    )

    val totalProductCount = repository.totalProductCount.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        0
    )

    val filteredProducts: StateFlow<List<ProductEntity>> = combine(
        allProducts,
        productSearchQuery,
        productCategoryFilter,
        productStockFilter
    ) { products, query, cat, stockFilter ->
        products.filter { p ->
            val matchQuery = query.isBlank() ||
                p.name.contains(query, ignoreCase = true) ||
                p.urduName.contains(query, ignoreCase = true) ||
                p.barcode.contains(query, ignoreCase = true)
            val matchCat = cat == "All" || p.category.equals(cat, ignoreCase = true)
            val matchStock = when (stockFilter) {
                "Low Stock" -> p.currentStock <= p.minStockThreshold
                "Out of Stock" -> p.currentStock <= 0
                else -> true
            }
            matchQuery && matchCat && matchStock
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun saveProduct(product: ProductEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            repository.saveProduct(product)
            onDone()
        }
    }

    fun adjustProductStock(productId: Long, delta: Double, reason: String) {
        viewModelScope.launch {
            repository.adjustStock(productId, delta, reason)
        }
    }

    fun archiveProduct(productId: Long) {
        viewModelScope.launch {
            repository.archiveProduct(productId)
        }
    }

    fun handleBarcodeScanned(barcode: String, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val product = repository.getProductByBarcode(barcode)
            if (product != null) {
                addToCart(product)
                onResult("Added ${product.name} to Cart")
            } else {
                onResult("Barcode $barcode not registered")
            }
        }
    }

    // ------------------------------------------------------------------------
    // KHATA & CUSTOMERS
    // ------------------------------------------------------------------------
    val customerSearchQuery = MutableStateFlow("")
    val allCustomers = repository.allCustomers.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val customersWithBalance: StateFlow<List<CustomerWithBalance>> = combine(
        allCustomers,
        customerSearchQuery
    ) { customers, query ->
        val filtered = if (query.isBlank()) {
            customers
        } else {
            customers.filter {
                it.name.contains(query, ignoreCase = true) || it.phone.contains(query)
            }
        }
        // compute balances reactively
        filtered.map { c ->
            val bal = repository.getCustomerBalance(c.id).first()
            CustomerWithBalance(c, bal)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalOutstandingCredit: StateFlow<Double> = customersWithBalance.combine(allCustomers) { list, _ ->
        list.sumOf { it.balance.coerceAtLeast(0.0) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val selectedCustomerForDetail = MutableStateFlow<CustomerEntity?>(null)
    private val _selectedCustomerLedger = MutableStateFlow<List<CustomerLedgerEntryEntity>>(emptyList())
    val selectedCustomerLedger: StateFlow<List<CustomerLedgerEntryEntity>> = _selectedCustomerLedger.asStateFlow()
    val selectedCustomerCurrentBalance = MutableStateFlow(0.0)

    fun selectCustomerForDetail(customer: CustomerEntity?) {
        selectedCustomerForDetail.value = customer
        if (customer != null) {
            viewModelScope.launch {
                repository.getCustomerLedger(customer.id).collect {
                    _selectedCustomerLedger.value = it
                }
            }
            viewModelScope.launch {
                repository.getCustomerBalance(customer.id).collect {
                    selectedCustomerCurrentBalance.value = it
                }
            }
        }
    }

    fun addCustomer(name: String, phone: String, address: String, openingBalance: Double, onDone: () -> Unit) {
        viewModelScope.launch {
            repository.saveCustomer(
                CustomerEntity(
                    name = name,
                    phone = phone,
                    address = address,
                    openingBalance = openingBalance
                )
            )
            onDone()
        }
    }

    fun receiveCustomerPayment(customerId: Long, amount: Double, notes: String, onDone: () -> Unit) {
        if (amount <= 0) return
        viewModelScope.launch {
            repository.recordCustomerPayment(customerId, amount, notes)
            selectCustomerForDetail(selectedCustomerForDetail.value)
            onDone()
        }
    }

    // ------------------------------------------------------------------------
    // SUPPLIERS & PURCHASES
    // ------------------------------------------------------------------------
    val allSuppliers = repository.allSuppliers.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    fun addSupplier(name: String, phone: String, address: String, openingBalance: Double, onDone: () -> Unit) {
        viewModelScope.launch {
            repository.saveSupplier(
                SupplierEntity(
                    name = name,
                    phone = phone,
                    address = address,
                    openingBalance = openingBalance
                )
            )
            onDone()
        }
    }

    fun recordSupplierPayment(supplierId: Long, amount: Double, notes: String, onDone: () -> Unit) {
        if (amount <= 0) return
        viewModelScope.launch {
            repository.recordSupplierPayment(supplierId, amount, notes)
            onDone()
        }
    }

    fun recordPurchase(
        supplierId: Long?,
        supplierName: String,
        invoiceNumber: String,
        productId: Long,
        productName: String,
        quantity: Double,
        unitCost: Double,
        amountPaid: Double,
        onDone: () -> Unit
    ) {
        viewModelScope.launch {
            val totalCost = quantity * unitCost
            val balanceDue = (totalCost - amountPaid).coerceAtLeast(0.0)
            val purchase = PurchaseEntity(
                invoiceNumber = invoiceNumber.ifBlank { "INV-${System.currentTimeMillis() % 10000}" },
                supplierId = supplierId,
                supplierName = supplierName,
                totalAmount = totalCost,
                amountPaid = amountPaid,
                balanceDue = balanceDue,
                notes = "Stock Purchase",
                timestamp = System.currentTimeMillis()
            )
            val item = PurchaseItemEntity(
                purchaseId = 0L,
                productId = productId,
                productName = productName,
                quantity = quantity,
                unitCost = unitCost,
                totalCost = totalCost
            )
            repository.recordPurchase(purchase, listOf(item))
            onDone()
        }
    }

    // ------------------------------------------------------------------------
    // EXPENSES
    // ------------------------------------------------------------------------
    val allExpenses = repository.allExpenses.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val expenseCategoryFilter = MutableStateFlow("All")

    val filteredExpenses = combine(allExpenses, expenseCategoryFilter) { expenses, cat ->
        if (cat == "All") expenses else expenses.filter { it.category.equals(cat, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addExpense(category: String, amount: Double, paymentMethod: String, notes: String, onDone: () -> Unit) {
        if (amount <= 0) return
        viewModelScope.launch {
            repository.saveExpense(
                ExpenseEntity(
                    category = category,
                    amount = amount,
                    paymentMethod = paymentMethod,
                    notes = notes,
                    timestamp = System.currentTimeMillis()
                )
            )
            refreshReports()
            onDone()
        }
    }

    fun deleteExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.deleteExpense(expense)
            refreshReports()
        }
    }

    // ------------------------------------------------------------------------
    // REPORTS & METRICS
    // ------------------------------------------------------------------------
    val reportDateRange = MutableStateFlow("TODAY") // "TODAY", "YESTERDAY", "THIS_WEEK", "THIS_MONTH", "ALL"
    private val _financialReport = MutableStateFlow(
        FinancialReport(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0)
    )
    val financialReport: StateFlow<FinancialReport> = _financialReport.asStateFlow()

    private val _todayFinancial = MutableStateFlow(
        FinancialReport(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0)
    )
    val todayFinancial: StateFlow<FinancialReport> = _todayFinancial.asStateFlow()

    val recentBills = repository.recentBills.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    fun setReportRange(range: String) {
        reportDateRange.value = range
        refreshReports()
    }

    fun refreshReports() {
        viewModelScope.launch {
            // Compute today's metrics
            val (todayStart, todayEnd) = getDayBounds(0)
            _todayFinancial.value = repository.calculateFinancialReport(todayStart, todayEnd)

            // Compute selected range metrics
            val (rangeStart, rangeEnd) = when (reportDateRange.value) {
                "YESTERDAY" -> getDayBounds(-1)
                "THIS_WEEK" -> getWeekBounds()
                "THIS_MONTH" -> getMonthBounds()
                "ALL" -> Pair(0L, System.currentTimeMillis() + 86400000L)
                else -> getDayBounds(0)
            }
            _financialReport.value = repository.calculateFinancialReport(rangeStart, rangeEnd)
        }
    }

    private fun getDayBounds(dayOffset: Int): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, dayOffset)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        cal.set(Calendar.MILLISECOND, 999)
        val end = cal.timeInMillis
        return Pair(start, end)
    }

    private fun getWeekBounds(): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        val start = cal.timeInMillis
        return Pair(start, System.currentTimeMillis())
    }

    private fun getMonthBounds(): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        val start = cal.timeInMillis
        return Pair(start, System.currentTimeMillis())
    }

    fun cancelBill(billId: Long, reason: String, onDone: () -> Unit) {
        viewModelScope.launch {
            repository.returnOrCancelBill(billId, reason)
            refreshReports()
            onDone()
        }
    }

    // ------------------------------------------------------------------------
    // SETTINGS & DATABASE RESET
    // ------------------------------------------------------------------------
    fun saveShopSettings(
        shopName: String,
        ownerName: String,
        phone: String,
        address: String,
        receiptFooter: String,
        onDone: () -> Unit
    ) {
        viewModelScope.launch {
            val cur = repository.getSettingsOnce()
            repository.saveSettings(
                cur.copy(
                    shopName = shopName,
                    ownerName = ownerName,
                    phone = phone,
                    address = address,
                    receiptFooter = receiptFooter
                )
            )
            onDone()
        }
    }

    fun resetToDefaultData(onDone: () -> Unit) {
        viewModelScope.launch {
            repository.resetDatabase()
            refreshReports()
            onDone()
        }
    }
}
