package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.entity.ProductEntity
import com.example.data.model.CurrencyFormatter
import com.example.ui.DukaanViewModel
import com.example.ui.components.BarcodeScannerModal
import com.example.ui.theme.DukaanGold
import com.example.ui.theme.DukaanGreenPrimary
import com.example.ui.theme.DukaanRedAlert

@Composable
fun ProductsScreen(
    viewModel: DukaanViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val products by viewModel.filteredProducts.collectAsState()
    val searchQuery by viewModel.productSearchQuery.collectAsState()
    val selectedCategory by viewModel.productCategoryFilter.collectAsState()
    val selectedStockFilter by viewModel.productStockFilter.collectAsState()

    var showAddEditDialog by remember { mutableStateOf(false) }
    var editingProduct by remember { mutableStateOf<ProductEntity?>(null) }
    var showStockAdjustDialog by remember { mutableStateOf(false) }
    var adjustingProduct by remember { mutableStateOf<ProductEntity?>(null) }
    var showScanner by remember { mutableStateOf(false) }

    val categories = listOf("All", "Atta & Dalen", "Ghee & Tel", "Chai & Cheeni", "Masalay", "Soap & Detergent", "Beverages & Milk", "Snacks & Biscuits", "General")
    val stockFilters = listOf("All", "Low Stock", "Out of Stock")

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search & Scan Bar
            Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.productSearchQuery.value = it },
                            placeholder = { Text("Search by name, Urdu, or barcode...", fontSize = 13.sp) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { viewModel.productSearchQuery.value = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear")
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = { showScanner = true },
                            modifier = Modifier
                                .size(50.dp)
                                .background(DukaanGreenPrimary, RoundedCornerShape(10.dp))
                        ) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan", tint = Color.White)
                        }
                    }

                    // Category filters
                    LazyRow(
                        modifier = Modifier.padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(categories) { cat ->
                            FilterChip(
                                selected = selectedCategory == cat,
                                onClick = { viewModel.productCategoryFilter.value = cat },
                                label = { Text(cat, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = DukaanGreenPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    // Stock status filters
                    LazyRow(
                        modifier = Modifier.padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(stockFilters) { filter ->
                            FilterChip(
                                selected = selectedStockFilter == filter,
                                onClick = { viewModel.productStockFilter.value = filter },
                                label = { Text(filter, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = if (filter == "Low Stock") DukaanGold else Color(0xFF6C757D),
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
            }

            // Products List
            if (products.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Inventory,
                            contentDescription = null,
                            tint = Color.LightGray,
                            modifier = Modifier.size(54.dp)
                        )
                        Text(
                            text = "Koi saman nahi mila\n(No products found matching filters)",
                            textAlign = TextAlign.Center,
                            color = Color.Gray,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(products, key = { it.id }) { product ->
                        ProductItemCard(
                            product = product,
                            onEdit = {
                                editingProduct = product
                                showAddEditDialog = true
                            },
                            onAdjustStock = {
                                adjustingProduct = product
                                showStockAdjustDialog = true
                            },
                            onArchive = {
                                viewModel.archiveProduct(product.id)
                                Toast.makeText(context, "${product.name} archived", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }
        }

        // FAB: Add Product
        FloatingActionButton(
            onClick = {
                editingProduct = null
                showAddEditDialog = true
            },
            containerColor = DukaanGreenPrimary,
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Product")
        }
    }

    // Add / Edit Product Dialog
    if (showAddEditDialog) {
        AddEditProductDialog(
            initialProduct = editingProduct,
            onDismiss = { showAddEditDialog = false },
            onSave = { product ->
                viewModel.saveProduct(product) {
                    showAddEditDialog = false
                    Toast.makeText(context, "Saman mehfooz hogaya (Product saved)", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    // Stock Adjust Dialog
    if (showStockAdjustDialog && adjustingProduct != null) {
        AdjustStockDialog(
            product = adjustingProduct!!,
            onDismiss = { showStockAdjustDialog = false },
            onConfirm = { delta, reason ->
                viewModel.adjustProductStock(adjustingProduct!!.id, delta, reason)
                showStockAdjustDialog = false
                Toast.makeText(context, "Stock tabdeel hogaya", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Scanner
    if (showScanner) {
        BarcodeScannerModal(
            onBarcodeScanned = { code ->
                viewModel.productSearchQuery.value = code
            },
            onDismiss = { showScanner = false }
        )
    }
}

@Composable
fun ProductItemCard(
    product: ProductEntity,
    onEdit: () -> Unit,
    onAdjustStock: () -> Unit,
    onArchive: () -> Unit
) {
    val isLowStock = product.currentStock <= product.minStockThreshold
    val isOutOfStock = product.currentStock <= 0

    val stockBadgeColor = when {
        isOutOfStock -> Color(0xFFF8D7DA)
        isLowStock -> Color(0xFFFFF3CD)
        else -> Color(0xFFD1E7DD)
    }

    val stockTextColor = when {
        isOutOfStock -> Color(0xFF842029)
        isLowStock -> Color(0xFF664D03)
        else -> Color(0xFF0F5132)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = product.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    if (product.urduName.isNotBlank()) {
                        Text(
                            text = product.urduName,
                            fontSize = 12.sp,
                            color = Color.DarkGray
                        )
                    }
                    if (product.barcode.isNotBlank()) {
                        Text(
                            text = "Barcode: ${product.barcode}",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }

                // Stock Badge
                Box(
                    modifier = Modifier
                        .background(stockBadgeColor, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${product.currentStock} ${product.unit}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = stockTextColor
                    )
                }
            }

            Divider(modifier = Modifier.padding(vertical = 8.dp))

            // Pricing & Actions Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Sale: ",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                        Text(
                            text = CurrencyFormatter.formatPkr(product.sellingPrice),
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp,
                            color = DukaanGreenPrimary
                        )
                    }
                    Text(
                        text = "Cost: ${CurrencyFormatter.formatPkr(product.costPrice)} | Margin: ${CurrencyFormatter.formatPkr(product.sellingPrice - product.costPrice)}",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }

                Row {
                    OutlinedButton(
                        onClick = onAdjustStock,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Text("Stock ±", fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(onClick = onEdit, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = Color.DarkGray, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onArchive, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Default.Archive, contentDescription = "Archive", tint = Color.LightGray, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun AddEditProductDialog(
    initialProduct: ProductEntity?,
    onDismiss: () -> Unit,
    onSave: (ProductEntity) -> Unit
) {
    var name by remember { mutableStateOf(initialProduct?.name ?: "") }
    var urduName by remember { mutableStateOf(initialProduct?.urduName ?: "") }
    var barcode by remember { mutableStateOf(initialProduct?.barcode ?: "") }
    var category by remember { mutableStateOf(initialProduct?.category ?: "General") }
    var unit by remember { mutableStateOf(initialProduct?.unit ?: "Piece") }
    var costPrice by remember { mutableStateOf(initialProduct?.costPrice?.toString() ?: "") }
    var sellingPrice by remember { mutableStateOf(initialProduct?.sellingPrice?.toString() ?: "") }
    var currentStock by remember { mutableStateOf(initialProduct?.currentStock?.toString() ?: "10") }
    var minStock by remember { mutableStateOf(initialProduct?.minStockThreshold?.toString() ?: "5") }

    val categories = listOf("Atta & Dalen", "Ghee & Tel", "Chai & Cheeni", "Masalay", "Soap & Detergent", "Beverages & Milk", "Snacks & Biscuits", "General")
    val units = listOf("Piece", "Kg", "Gram", "Packet", "Pouch", "Liter", "Dozen", "Bag")

    var showCategoryMenu by remember { mutableStateOf(false) }
    var showUnitMenu by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(scrollState)
            ) {
                Text(
                    text = if (initialProduct == null) "Naya Saman Shamil Karein (Add Product)" else "Saman Edit Karein",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = DukaanGreenPrimary
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Product English Name *") },
                    placeholder = { Text("e.g. Atta 10kg") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = urduName,
                    onValueChange = { urduName = it },
                    label = { Text("Urdu / Local Name (اختیاری)") },
                    placeholder = { Text("e.g. آٹا 10 کلو") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = barcode,
                    onValueChange = { barcode = it },
                    label = { Text("Barcode Number (Optional)") },
                    placeholder = { Text("e.g. 89640001001") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    singleLine = true
                )

                // Category & Unit Selector Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedButton(
                            onClick = { showCategoryMenu = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Cat: $category", fontSize = 11.sp, maxLines = 1)
                        }
                        DropdownMenu(
                            expanded = showCategoryMenu,
                            onDismissRequest = { showCategoryMenu = false }
                        ) {
                            for (cat in categories) {
                                DropdownMenuItem(
                                    text = { Text(cat) },
                                    onClick = {
                                        category = cat
                                        showCategoryMenu = false
                                    }
                                )
                            }
                        }
                    }

                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedButton(
                            onClick = { showUnitMenu = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Unit: $unit", fontSize = 11.sp, maxLines = 1)
                        }
                        DropdownMenu(
                            expanded = showUnitMenu,
                            onDismissRequest = { showUnitMenu = false }
                        ) {
                            for (u in units) {
                                DropdownMenuItem(
                                    text = { Text(u) },
                                    onClick = {
                                        unit = u
                                        showUnitMenu = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Cost & Selling Price
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = costPrice,
                        onValueChange = { costPrice = it },
                        label = { Text("Khareed (Cost) *") },
                        placeholder = { Text("120") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = sellingPrice,
                        onValueChange = { sellingPrice = it },
                        label = { Text("Sale Price *") },
                        placeholder = { Text("140") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                // Initial Stock & Min threshold
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = currentStock,
                        onValueChange = { currentStock = it },
                        label = { Text("Stock Quantity") },
                        placeholder = { Text("10") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = minStock,
                        onValueChange = { minStock = it },
                        label = { Text("Low Stock Alert") },
                        placeholder = { Text("5") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            if (name.isBlank()) return@Button
                            val cost = costPrice.toDoubleOrNull() ?: 0.0
                            val sell = sellingPrice.toDoubleOrNull() ?: cost
                            val stock = currentStock.toDoubleOrNull() ?: 0.0
                            val threshold = minStock.toDoubleOrNull() ?: 5.0

                            val toSave = initialProduct?.copy(
                                name = name.trim(),
                                urduName = urduName.trim(),
                                barcode = barcode.trim(),
                                category = category,
                                unit = unit,
                                costPrice = cost,
                                sellingPrice = sell,
                                currentStock = stock,
                                minStockThreshold = threshold,
                                updatedAt = System.currentTimeMillis()
                            ) ?: ProductEntity(
                                name = name.trim(),
                                urduName = urduName.trim(),
                                barcode = barcode.trim(),
                                category = category,
                                unit = unit,
                                costPrice = cost,
                                sellingPrice = sell,
                                currentStock = stock,
                                minStockThreshold = threshold
                            )

                            onSave(toSave)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = DukaanGreenPrimary),
                        enabled = name.isNotBlank() && costPrice.isNotBlank() && sellingPrice.isNotBlank()
                    ) {
                        Text("Save (محفوظ)")
                    }
                }
            }
        }
    }
}

@Composable
fun AdjustStockDialog(
    product: ProductEntity,
    onDismiss: () -> Unit,
    onConfirm: (Double, String) -> Unit
) {
    var deltaText by remember { mutableStateOf("1") }
    var isAddition by remember { mutableStateOf(true) }
    var reason by remember { mutableStateOf("Naya Mal Aaya (Purchase)") }

    val presetReasons = listOf(
        "Naya Mal Aaya (Purchase)",
        "Ginti Durustgi (Physical Count)",
        "Kharab / Zaya Hogaya (Damaged)",
        "Expiry Hogayi (Expired)",
        "Wapsi (Return)"
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Stock Tabdeel Karein (Adjust Stock)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = "${product.name} (Mojooda: ${product.currentStock} ${product.unit})",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 2.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Toggle + / -
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { isAddition = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isAddition) DukaanGreenPrimary else Color(0xFFE9ECEF)
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("+ Mal Izafa (Add)", color = if (isAddition) Color.White else Color.Black)
                    }
                    Button(
                        onClick = { isAddition = false },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (!isAddition) DukaanRedAlert else Color(0xFFE9ECEF)
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("- Mal Kami (Deduct)", color = if (!isAddition) Color.White else Color.Black)
                    }
                }

                OutlinedTextField(
                    value = deltaText,
                    onValueChange = { deltaText = it },
                    label = { Text("Quantity (${product.unit})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    singleLine = true
                )

                Text(
                    text = "Reason (Waja):",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 8.dp)
                )

                LazyRow(
                    modifier = Modifier.padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(presetReasons) { r ->
                        FilterChip(
                            selected = reason == r,
                            onClick = { reason = r },
                            label = { Text(r, fontSize = 10.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val qty = deltaText.toDoubleOrNull() ?: 0.0
                            val delta = if (isAddition) qty else -qty
                            onConfirm(delta, reason)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = DukaanGreenPrimary)
                    ) {
                        Text("Confirm")
                    }
                }
            }
        }
    }
}
