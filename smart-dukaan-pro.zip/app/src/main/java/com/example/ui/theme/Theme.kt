package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF6EDC98),
    onPrimary = Color(0xFF00391A),
    primaryContainer = DukaanGreenDark,
    onPrimaryContainer = Color(0xFF8CF8B3),
    secondary = Color(0xFFFFD54F),
    onSecondary = Color(0xFF3F2E00),
    secondaryContainer = Color(0xFF5A4300),
    onSecondaryContainer = Color(0xFFFFE082),
    tertiary = Color(0xFFFFB4AB),
    error = Color(0xFFFFB4AB),
    background = DukaanDarkBg,
    surface = DukaanDarkSurface,
    onBackground = Color(0xFFE6E1E5),
    onSurface = Color(0xFFE6E1E5)
)

private val LightColorScheme = lightColorScheme(
    primary = DukaanGreenPrimary,
    onPrimary = Color.White,
    primaryContainer = DukaanGreenContainer,
    onPrimaryContainer = DukaanOnGreenContainer,
    secondary = DukaanGold,
    onSecondary = Color.White,
    secondaryContainer = DukaanGoldLight,
    onSecondaryContainer = DukaanGoldDark,
    tertiary = DukaanRedAlert,
    error = DukaanRedAlert,
    background = DukaanSurfaceLight,
    surface = DukaanSurfaceCard,
    onBackground = Color(0xFF212529),
    onSurface = Color(0xFF212529),
    outline = DukaanBorder
)

@Composable
fun SmartDukaanTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep consistent brand colors for Dukaan
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
