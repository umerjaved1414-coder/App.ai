package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.CustomerLedgerEntryEntity
import com.example.data.model.CurrencyFormatter
import com.example.ui.CustomerWithBalance
import com.example.ui.DukaanViewModel
import com.example.ui.theme.DukaanGreenPrimary
import com.example.ui.theme.DukaanRedAlert
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun KhataScreen(
    viewModel: DukaanViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val customersWithBalance by viewModel.customersWithBalance.collectAsState()
    val totalCredit by viewModel.totalOutstandingCredit.collectAsState()
    val searchQuery by viewModel.customerSearchQuery.collectAsState()

    val selectedCustomer by viewModel.selectedCustomerForDetail.collectAsState()
    val ledgerEntries by viewModel.selectedCustomerLedger.collectAsState()
    val currentBalance by viewModel.selectedCustomerCurrentBalance.collectAsState()

    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var showPaymentDialog by remember { mutableStateOf(false) }

    if (selectedCustomer != null) {
        // Customer Ledger Detail View
        CustomerLedgerDetailView(
            customer = selectedCustomer!!,
            balance = currentBalance,
            ledger = ledgerEntries,
            onBack = { viewModel.selectCustomerForDetail(null) },
            onReceivePayment = { showPaymentDialog = true },
            onShareStatement = {
                val statement = buildCustomerStatement(selectedCustomer!!, currentBalance, ledgerEntries)
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "Khata Hisab: ${selectedCustomer!!.name}")
                    putExtra(Intent.EXTRA_TEXT, statement)
                }
                context.startActivity(Intent.createChooser(shareIntent, "Share Khata Statement"))
            }
        )
    } else {
        // Customers List View
        Box(modifier = modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Header Summary Card
                Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF8D7DA)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Kul Market Udhar (Total Baqi)",
                                        fontSize = 12.sp,
                                        color = Color(0xFF842029),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = CurrencyFormatter.formatPkr(totalCredit),
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = DukaanRedAlert
                                    )
                                }
                                Text(
                                    text = "${customersWithBalance.size} Grahak\n(Customers)",
                                    fontSize = 12.sp,
                                    color = Color(0xFF842029),
                                    textAlign = TextAlign.End
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Customer Search Bar
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.customerSearchQuery.value = it },
                            placeholder = { Text("Search customer name or phone...", fontSize = 13.sp) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { viewModel.customerSearchQuery.value = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear")
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                }

                // Customers List
                if (customersWithBalance.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Default.Person,
                                contentDescription = null,
                                tint = Color.LightGray,
                                modifier = Modifier.size(54.dp)
                            )
                            Text(
                                text = "Koi grahak nahi mila\n(Tap '+' to add new customer)",
                                textAlign = TextAlign.Center,
                                color = Color.Gray,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(customersWithBalance, key = { it.customer.id }) { item ->
                            CustomerKhataCard(item = item) {
                                viewModel.selectCustomerForDetail(item.customer)
                            }
                        }
                    }
                }
            }

            // FAB: Add Customer
            FloatingActionButton(
                onClick = { showAddCustomerDialog = true },
                containerColor = DukaanGreenPrimary,
                contentColor = Color.White,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(20.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Customer")
            }
        }
    }

    // Add Customer Dialog
    if (showAddCustomerDialog) {
        AddCustomerDialog(
            onDismiss = { showAddCustomerDialog = false },
            onSave = { name, phone, address, openingBal ->
                viewModel.addCustomer(name, phone, address, openingBal) {
                    showAddCustomerDialog = false
                    Toast.makeText(context, "Naya Grahak mehfooz hogaya", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    // Receive Payment Modal
    if (showPaymentDialog && selectedCustomer != null) {
        ReceivePaymentDialog(
            customer = selectedCustomer!!,
            onDismiss = { showPaymentDialog = false },
            onConfirm = { amount, notes ->
                viewModel.receiveCustomerPayment(selectedCustomer!!.id, amount, notes) {
                    showPaymentDialog = false
                    Toast.makeText(context, "Jama wasool darj hogayi (Payment recorded)", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }
}

@Composable
fun CustomerKhataCard(
    item: CustomerWithBalance,
    onClick: () -> Unit
) {
    val cust = item.customer
    val bal = item.balance

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color(0xFFE8F5E9), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = cust.name.take(1).uppercase(),
                        fontWeight = FontWeight.Bold,
                        color = DukaanGreenPrimary,
                        fontSize = 16.sp
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = cust.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    if (cust.phone.isNotBlank()) {
                        Text(
                            text = cust.phone,
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = CurrencyFormatter.formatPkr(bal),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    color = if (bal > 0) DukaanRedAlert else Color(0xFF2E7D32)
                )
                Text(
                    text = if (bal > 0) "Baqi Udhar (Due)" else "Clear / Hisab Barabar",
                    fontSize = 10.sp,
                    color = if (bal > 0) DukaanRedAlert else Color(0xFF2E7D32),
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
fun CustomerLedgerDetailView(
    customer: CustomerEntity,
    balance: Double,
    ledger: List<CustomerLedgerEntryEntity>,
    onBack: () -> Unit,
    onReceivePayment: () -> Unit,
    onShareStatement: () -> Unit
) {
    val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top App Bar
        Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                    Column {
                        Text(text = customer.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        if (customer.phone.isNotBlank()) {
                            Text(text = customer.phone, fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }
                IconButton(onClick = onShareStatement) {
                    Icon(Icons.Default.Share, contentDescription = "Share", tint = DukaanGreenPrimary)
                }
            }
        }

        // Balance Summary Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (balance > 0) Color(0xFFF8D7DA) else Color(0xFFD1E7DD)
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Current Outstanding (کل واجب الادا باقی):",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (balance > 0) Color(0xFF842029) else Color(0xFF0F5132)
                    )
                    Text(
                        text = CurrencyFormatter.formatPkr(balance),
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (balance > 0) DukaanRedAlert else Color(0xFF0F5132)
                    )
                }

                Button(
                    onClick = onReceivePayment,
                    colors = ButtonDefaults.buttonColors(containerColor = DukaanGreenPrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("+ Jama Wasool", fontSize = 12.sp)
                }
            }
        }

        // WhatsApp Reminder Button
        if (balance > 0) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(
                    onClick = onShareStatement,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("WhatsApp Reminder Bhejein", fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Khata Tafseel (Ledger Statement):",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
        )

        // Ledger Table Entries
        if (ledger.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("No ledger entries recorded yet", color = Color.Gray, fontSize = 13.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(ledger.reversed()) { entry ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = entry.description,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = sdf.format(Date(entry.timestamp)),
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                val isDebit = entry.type == "DEBIT"
                                Text(
                                    text = (if (isDebit) "+ " else "- ") + CurrencyFormatter.formatPkr(entry.amount),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 14.sp,
                                    color = if (isDebit) DukaanRedAlert else Color(0xFF2E7D32)
                                )
                                Text(
                                    text = if (isDebit) "Udhar (Credit Sale)" else "Jama (Payment)",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddCustomerDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, String, Double) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var openingBalance by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Naya Grahak Darj Karein (Add Customer)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = DukaanGreenPrimary
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Grahak Ka Naam (Name) *") },
                    placeholder = { Text("e.g. Master Aslam") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Mobile / WhatsApp Number") },
                    placeholder = { Text("e.g. 0300-1234567") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Pata / Address (Optional)") },
                    placeholder = { Text("Street / Area") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = openingBalance,
                    onValueChange = { openingBalance = it },
                    label = { Text("Sabqa Udhar / Opening Balance (Rs.)") },
                    placeholder = { Text("0") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            if (name.isBlank()) return@Button
                            val bal = openingBalance.toDoubleOrNull() ?: 0.0
                            onSave(name.trim(), phone.trim(), address.trim(), bal)
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = DukaanGreenPrimary),
                        enabled = name.isNotBlank()
                    ) {
                        Text("Save (محفوظ)")
                    }
                }
            }
        }
    }
}

@Composable
fun ReceivePaymentDialog(
    customer: CustomerEntity,
    onDismiss: () -> Unit,
    onConfirm: (Double, String) -> Unit
) {
    var amountText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("Naqad Wasooli (Cash Received)") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Jama Wasooli (Receive Payment)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color(0xFF2E7D32)
                )
                Text(
                    text = "Grahak: ${customer.name}",
                    fontSize = 13.sp,
                    color = Color.DarkGray,
                    modifier = Modifier.padding(top = 2.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Wasool Shuda Rakam (Amount) *") },
                    placeholder = { Text("e.g. 500") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Tafseel / Notes") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val amt = amountText.toDoubleOrNull() ?: 0.0
                            if (amt > 0) {
                                onConfirm(amt, notes.trim())
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        enabled = amountText.toDoubleOrNull() != null && (amountText.toDoubleOrNull() ?: 0.0) > 0
                    ) {
                        Text("Save Jama")
                    }
                }
            }
        }
    }
}

fun buildCustomerStatement(
    customer: CustomerEntity,
    currentBalance: Double,
    ledger: List<CustomerLedgerEntryEntity>
): String {
    val sdf = SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault())
    val dateStr = sdf.format(Date())

    val sb = StringBuilder()
    sb.append("محترم جناب ${customer.name} صاحب!\n")
    sb.append("السلام علیکم!\n")
    sb.append("آپ کے کریانہ کھاتہ کی تفصیل:\n")
    sb.append("-----------------------------\n")
    sb.append("تاریخ: $dateStr\n")
    sb.append("کل واجب الادا رقم: Rs. ${currentBalance.toInt()}\n")
    sb.append("-----------------------------\n")
    sb.append("آخری ٹرانزیکشنز:\n")
    for (entry in ledger.takeLast(5)) {
        val type = if (entry.type == "DEBIT") "ادھار (+)" else "جمع (-)"
        val dt = SimpleDateFormat("dd/MM", Locale.getDefault()).format(Date(entry.timestamp))
        sb.append("$dt - ${entry.description}: Rs. ${entry.amount.toInt()} ($type)\n")
    }
    sb.append("-----------------------------\n")
    sb.append("برائے مہربانی بقایا رقم جلد ادا فرمائیں۔ شکریہ!\n")
    sb.append("Smart Dukaan Pro")

    return sb.toString()
}
