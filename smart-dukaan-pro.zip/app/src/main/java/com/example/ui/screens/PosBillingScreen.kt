package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.model.CartItem
import com.example.data.model.CurrencyFormatter
import com.example.data.model.ReceiptData
import com.example.ui.DukaanViewModel
import com.example.ui.components.BarcodeScannerModal
import com.example.ui.components.ReceiptDialog
import com.example.ui.theme.DukaanGold
import com.example.ui.theme.DukaanGreenPrimary
import com.example.ui.theme.DukaanRedAlert

@Composable
fun PosBillingScreen(
    viewModel: DukaanViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val cartItems by viewModel.cartItems.collectAsState()
    val subtotal by viewModel.cartSubtotal.collectAsState()
    val grandTotal by viewModel.cartGrandTotal.collectAsState()
    val discount by viewModel.billDiscount.collectAsState()
    val amountReceived by viewModel.amountReceivedInput.collectAsState()
    val selectedCustomer by viewModel.selectedCustomer.collectAsState()
    val paymentMethod by viewModel.paymentMethod.collectAsState()
    val allCustomers by viewModel.allCustomers.collectAsState()

    val allProducts by viewModel.allProducts.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var showScanner by remember { mutableStateOf(false) }
    var showCustomerPicker by remember { mutableStateOf(false) }
    var activeReceipt by remember { mutableStateOf<ReceiptData?>(null) }

    val categories = listOf("All", "Atta & Dalen", "Ghee & Tel", "Chai & Cheeni", "Masalay", "Soap & Detergent", "Snacks & Biscuits")

    val matchingProducts = remember(searchQuery, selectedCategory, allProducts) {
        allProducts.filter { p ->
            val matchQuery = searchQuery.isBlank() ||
                p.name.contains(searchQuery, ignoreCase = true) ||
                p.urduName.contains(searchQuery, ignoreCase = true) ||
                p.barcode.contains(searchQuery, ignoreCase = true)
            val matchCategory = selectedCategory == "All" || p.category.equals(selectedCategory, ignoreCase = true)
            matchQuery && matchCategory
        }
    }

    val receivedNum = amountReceived.toDoubleOrNull() ?: 0.0
    val balanceDue = if (paymentMethod == "KHATA") {
        grandTotal
    } else if (paymentMethod == "PARTIAL") {
        (grandTotal - receivedNum).coerceAtLeast(0.0)
    } else {
        0.0
    }

    val changeReturn = if (paymentMethod == "CASH" && receivedNum > grandTotal) {
        receivedNum - grandTotal
    } else 0.0

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Search & Barcode Bar
        Surface(
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Search product name / barcode...", fontSize = 13.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear")
                                }
                            }
                        },
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { showScanner = true },
                        colors = ButtonDefaults.buttonColors(containerColor = DukaanGreenPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.height(56.dp)
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Scan", fontSize = 12.sp)
                    }
                }

                // Category Chips
                LazyRow(
                    modifier = Modifier.padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = DukaanGreenPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        // Quick Products Picker Row (shows tap-to-add items)
        if (matchingProducts.isNotEmpty()) {
            Text(
                text = "Tap item to add to bill (+):",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.DarkGray,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
            )
            LazyRow(
                modifier = Modifier.padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(matchingProducts.take(8)) { product ->
                    Card(
                        modifier = Modifier
                            .clickable { viewModel.addToCart(product) }
                            .width(140.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text(
                                text = product.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                maxLines = 1
                            )
                            if (product.urduName.isNotBlank()) {
                                Text(
                                    text = product.urduName,
                                    fontSize = 10.sp,
                                    color = Color.Gray,
                                    maxLines = 1
                                )
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = CurrencyFormatter.formatPkr(product.sellingPrice, ""),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 12.sp,
                                    color = DukaanGreenPrimary
                                )
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .background(DukaanGreenPrimary, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        // Main Cart & Checkout Area
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Cart (${cartItems.size} items)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    if (cartItems.isNotEmpty()) {
                        Text(
                            text = "Clear Cart (صاف کریں)",
                            fontSize = 12.sp,
                            color = DukaanRedAlert,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clickable { viewModel.clearCart() }
                        )
                    }
                }
            }

            if (cartItems.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.ShoppingCart,
                                contentDescription = null,
                                tint = Color.LightGray,
                                modifier = Modifier.size(44.dp)
                            )
                            Text(
                                text = "Bill Khali Hai\n(Tap products above or Scan Barcode to add)",
                                textAlign = TextAlign.Center,
                                color = Color.Gray,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                    }
                }
            } else {
                items(cartItems) { item ->
                    CartItemRow(
                        item = item,
                        onQuantityChange = { newQty -> viewModel.updateCartItemQuantity(item.product.id, newQty) },
                        onRemove = { viewModel.removeFromCart(item.product.id) }
                    )
                }
            }

            // Customer Selector & Payment Settings
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        // Customer Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = DukaanGreenPrimary)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Grahak (Customer):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Text(
                                text = selectedCustomer?.name ?: "Walk-in Cash",
                                fontWeight = FontWeight.Bold,
                                color = if (selectedCustomer != null) DukaanGreenPrimary else Color.DarkGray,
                                fontSize = 13.sp
                            )
                        }

                        // Select Customer Button
                        Box(modifier = Modifier.padding(top = 6.dp)) {
                            OutlinedButton(
                                onClick = { showCustomerPicker = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    if (selectedCustomer == null) "Select Khata Grahak (کھاتہ دار منتخب کریں)" else "Change Customer"
                                )
                            }

                            DropdownMenu(
                                expanded = showCustomerPicker,
                                onDismissRequest = { showCustomerPicker = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Walk-in Cash Customer (عام نقد گاہک)") },
                                    onClick = {
                                        viewModel.selectedCustomer.value = null
                                        showCustomerPicker = false
                                    }
                                )
                                Divider()
                                for (cust in allCustomers) {
                                    DropdownMenuItem(
                                        text = { Text("${cust.name} (${cust.phone})") },
                                        onClick = {
                                            viewModel.selectedCustomer.value = cust
                                            showCustomerPicker = false
                                        }
                                    )
                                }
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 10.dp))

                        // Payment Method Selector
                        Text("Payment Type (ادائیگی کا طریقہ):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            PaymentTypeButton(
                                label = "Naqad (Cash)",
                                isSelected = paymentMethod == "CASH",
                                modifier = Modifier.weight(1f)
                            ) { viewModel.paymentMethod.value = "CASH" }

                            PaymentTypeButton(
                                label = "Udhar (Khata)",
                                isSelected = paymentMethod == "KHATA",
                                modifier = Modifier.weight(1f)
                            ) { viewModel.paymentMethod.value = "KHATA" }

                            PaymentTypeButton(
                                label = "Kuch Cash",
                                isSelected = paymentMethod == "PARTIAL",
                                modifier = Modifier.weight(1f)
                            ) { viewModel.paymentMethod.value = "PARTIAL" }
                        }

                        // Payment breakdown / inputs
                        if (paymentMethod == "PARTIAL" || paymentMethod == "CASH") {
                            OutlinedTextField(
                                value = amountReceived,
                                onValueChange = { viewModel.amountReceivedInput.value = it },
                                label = { Text("Wasool Rakam (Cash Given by Customer)") },
                                placeholder = { Text("e.g. 1000") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp),
                                singleLine = true
                            )
                        }

                        // Discount Row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Riyayat / Discount (Rs.):", fontSize = 12.sp)
                            var discountText by remember { mutableStateOf(if (discount > 0) discount.toString() else "") }
                            OutlinedTextField(
                                value = discountText,
                                onValueChange = {
                                    discountText = it
                                    viewModel.billDiscount.value = it.toDoubleOrNull() ?: 0.0
                                },
                                modifier = Modifier.width(110.dp),
                                placeholder = { Text("0") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                        }

                        Divider(modifier = Modifier.padding(vertical = 8.dp))

                        // Financial Summary Totals
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Subtotal:", fontSize = 13.sp)
                            Text(CurrencyFormatter.formatPkr(subtotal), fontSize = 13.sp)
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("GRAND TOTAL (ٹوٹل رقم):", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(
                                CurrencyFormatter.formatPkr(grandTotal),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = DukaanGreenPrimary
                            )
                        }

                        if (paymentMethod == "KHATA" || (paymentMethod == "PARTIAL" && balanceDue > 0)) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Grahak Ke Zimme Baqi (Udhar):", fontWeight = FontWeight.Bold, color = DukaanRedAlert, fontSize = 13.sp)
                                Text(CurrencyFormatter.formatPkr(balanceDue), fontWeight = FontWeight.Bold, color = DukaanRedAlert, fontSize = 13.sp)
                            }
                        }

                        if (changeReturn > 0) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Wapsi Baqi (Change to Return):", fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32), fontSize = 13.sp)
                                Text(CurrencyFormatter.formatPkr(changeReturn), fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32), fontSize = 13.sp)
                            }
                        }
                    }
                }
            }

            // Big Complete Bill Button
            item {
                Button(
                    onClick = {
                        viewModel.completeSale(
                            onSuccess = { receipt ->
                                activeReceipt = receipt
                            },
                            onError = { err ->
                                Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                            }
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .padding(bottom = 8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DukaanGreenPrimary),
                    shape = RoundedCornerShape(12.dp),
                    enabled = cartItems.isNotEmpty()
                ) {
                    Text(
                        text = "BILL MUKAMMAL KAREIN (مکمل کریں اور رسید)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }

    // Barcode scanner modal
    if (showScanner) {
        BarcodeScannerModal(
            onBarcodeScanned = { code ->
                viewModel.handleBarcodeScanned(code) { msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                }
            },
            onDismiss = { showScanner = false }
        )
    }

    // Active receipt preview dialog upon successful sale
    activeReceipt?.let { receipt ->
        ReceiptDialog(receipt = receipt) {
            activeReceipt = null
        }
    }
}

@Composable
fun PaymentTypeButton(
    label: String,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .background(
                if (isSelected) DukaanGreenPrimary else Color(0xFFE9ECEF),
                RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (isSelected) Color.White else Color.Black
        )
    }
}

@Composable
fun CartItemRow(
    item: CartItem,
    onQuantityChange: (Double) -> Unit,
    onRemove: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1.5f)) {
                Text(
                    text = item.product.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1
                )
                Text(
                    text = "Rate: ${CurrencyFormatter.formatPkr(item.unitPrice, "")} / ${item.product.unit}",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }

            // Qty +/- Stepper
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .border(1.dp, Color(0xFFDDDDDD), RoundedCornerShape(8.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                IconButton(
                    onClick = { onQuantityChange(item.quantity - 1.0) },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "Minus", modifier = Modifier.size(16.dp))
                }
                Text(
                    text = "${item.quantity.toInt().coerceAtLeast(1)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )
                IconButton(
                    onClick = { onQuantityChange(item.quantity + 1.0) },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add", modifier = Modifier.size(16.dp))
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Line Total & Delete
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = CurrencyFormatter.formatPkr(item.lineTotal),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp,
                    color = DukaanGreenPrimary
                )
                IconButton(onClick = onRemove, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Remove", tint = Color.Gray, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}
