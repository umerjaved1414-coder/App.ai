package com.example

import com.example.data.local.entity.BillEntity
import com.example.data.local.entity.BillItemEntity
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.CustomerLedgerEntryEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.model.CartItem
import com.example.data.model.CurrencyFormatter
import com.example.data.model.FinancialReport
import com.example.data.model.ReceiptData
import com.example.ui.screens.buildBusinessReportText
import com.example.ui.screens.buildCustomerStatement
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartDukaanBusinessTest {

    @Test
    fun testCurrencyFormatting() {
        val formatted = CurrencyFormatter.formatPkr(1450.0)
        assertEquals("Rs. 1,450", formatted)

        val formattedWithPkr = CurrencyFormatter.formatPkr(25000.0, "PKR")
        assertEquals("PKR 25,000", formattedWithPkr)
    }

    @Test
    fun testCartCalculationsAndDiscounts() {
        val productAtta = ProductEntity(
            id = 1L,
            name = "Atta 10kg",
            costPrice = 1380.0,
            sellingPrice = 1450.0,
            currentStock = 20.0
        )
        val productGhee = ProductEntity(
            id = 2L,
            name = "Sufi Ghee 1kg",
            costPrice = 490.0,
            sellingPrice = 530.0,
            currentStock = 15.0
        )

        val item1 = CartItem(product = productAtta, quantity = 2.0, unitPrice = 1450.0)
        val item2 = CartItem(product = productGhee, quantity = 3.0, unitPrice = 530.0, discount = 40.0)

        // Line totals
        assertEquals(2900.0, item1.lineTotal, 0.01) // 2 * 1450
        assertEquals(1550.0, item2.lineTotal, 0.01) // (3 * 530) - 40 = 1590 - 40 = 1550

        val subtotal = item1.lineTotal + item2.lineTotal
        assertEquals(4450.0, subtotal, 0.01)

        val billDiscount = 150.0
        val grandTotal = (subtotal - billDiscount).coerceAtLeast(0.0)
        assertEquals(4300.0, grandTotal, 0.01)

        // Partial payment test
        val amountReceived = 3000.0
        val balanceDue = (grandTotal - amountReceived).coerceAtLeast(0.0)
        assertEquals(1300.0, balanceDue, 0.01)

        // Cash change returned test
        val cashPaid = 5000.0
        val changeReturn = (cashPaid - grandTotal).coerceAtLeast(0.0)
        assertEquals(700.0, changeReturn, 0.01)
    }

    @Test
    fun testGrossAndNetProfitCalculation() {
        val totalSales = 10000.0
        val cogs = 8200.0 // purchase cost of goods sold
        val operatingExpenses = 650.0 // shop electricity, bags, etc.

        val grossProfit = totalSales - cogs
        val netProfit = grossProfit - operatingExpenses

        val report = FinancialReport(
            totalSales = totalSales,
            cogs = cogs,
            grossProfit = grossProfit,
            totalExpenses = operatingExpenses,
            netProfit = netProfit,
            collectedCash = 9000.0,
            creditSales = 1000.0,
            billsCount = 12
        )

        assertEquals(1800.0, report.grossProfit, 0.01)
        assertEquals(1150.0, report.netProfit, 0.01)
        assertEquals(12, report.billsCount)
    }

    @Test
    fun testReceiptTextFormatting() {
        val items = listOf(
            BillItemEntity(
                billId = 1L,
                productId = 1L,
                productName = "Atta 10kg Bag",
                unit = "Bag",
                unitCostSnapshot = 1380.0,
                unitPriceSnapshot = 1450.0,
                quantity = 1.0,
                totalPrice = 1450.0
            )
        )

        val receipt = ReceiptData(
            shopName = "Bismillah Kiryana Store",
            ownerName = "Muhammad Ali",
            phone = "0300-1234567",
            address = "Main Bazar, Lahore",
            billNumber = "SD-10023",
            timestamp = 1700000000000L,
            customerName = "Haji Tariq",
            items = items,
            subtotal = 1450.0,
            discount = 50.0,
            grandTotal = 1400.0,
            amountPaid = 1000.0,
            balanceDue = 400.0,
            paymentMethod = "PARTIAL",
            footerMessage = "Shukriya! Dobara Tashreef Layen."
        )

        val text = receipt.formatReceiptText()
        assertTrue(text.contains("BISMILLAH KIRYANA STORE"))
        assertTrue(text.contains("SD-10023"))
        assertTrue(text.contains("Atta 10kg"))
        assertTrue(text.contains("Rs.     1400"))
        assertTrue(text.contains("BAQI UDHAR (Due)"))
        assertTrue(text.contains("Shukriya! Dobara Tashreef Layen."))
    }

    @Test
    fun testCustomerStatementGeneration() {
        val customer = CustomerEntity(
            id = 1L,
            name = "Master Aslam",
            phone = "0321-9876543"
        )
        val ledger = listOf(
            CustomerLedgerEntryEntity(
                customerId = 1L,
                type = "DEBIT",
                amount = 2500.0,
                description = "Rashan Sauda",
                timestamp = System.currentTimeMillis()
            ),
            CustomerLedgerEntryEntity(
                customerId = 1L,
                type = "CREDIT",
                amount = 1000.0,
                description = "Naqad Jama",
                timestamp = System.currentTimeMillis()
            )
        )

        val statement = buildCustomerStatement(customer, 1500.0, ledger)
        assertTrue(statement.contains("Master Aslam"))
        assertTrue(statement.contains("Rs. 1500"))
        assertTrue(statement.contains("Smart Dukaan Pro"))
    }
}
